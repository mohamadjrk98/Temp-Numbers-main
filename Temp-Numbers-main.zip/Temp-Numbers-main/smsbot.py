import logging
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes, ConversationHandler
import requests
import time
import os
from dotenv import load_dotenv
from supabase import create_client, Client
import bcrypt
from io import BytesIO

# ----------------------------------------
# 1. الإعدادات وتحميل المتغيرات
# ----------------------------------------

# Load env vars
load_dotenv()

# Variables loaded from environment
USERNAME = os.getenv('USERNAME')
API_KEY = os.getenv('API_KEY')
PID = int(os.getenv('PID', 0))
BOT_TOKEN = os.getenv('BOT_TOKEN')
COUNTRY = os.getenv('COUNTRY', 'bo')
NUM_COUNT = int(os.getenv('NUM_COUNT', 1))
SERIAL = int(os.getenv('SERIAL', 2))
ADMIN_ID = int(os.getenv('ADMIN_ID', 0))

# Supabase setup
SUPABASE_URL = os.getenv('SUPABASE_URL')
SUPABASE_KEY = os.getenv('SUPABASE_KEY')
try:
    supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
except Exception as e:
    logging.error(f"Failed to create Supabase client: {e}")
    raise

if not all([BOT_TOKEN, USERNAME, API_KEY, PID, SUPABASE_URL, SUPABASE_KEY]):
    raise ValueError("Missing required environment variables!")

BASE_URL = "https://api.durianrcs.com/out/ext_api"

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# States for Registration Conversation
USERNAME_STATE, PASSWORD_STATE, CAPTCHA_STATE = range(3)
# Additional States for Admin Conversation (for clarity, although managed via user_data in button_handler)
ADMIN_EDIT_PRICE_STATE = 3
ADMIN_EDIT_ADDRESS_STATE = 4

# ----------------------------------------
# 2. رسائل البوت (التعريب)
# ----------------------------------------

def get_messages():
    """Returns a dictionary of bot messages."""
    return {
        'welcome': 'مرحباً! قم بإنشاء حسابك:',
        'ask_username': 'أرسل اسم المستخدم:',
        'username_saved': 'تم حفظ اسم المستخدم. الآن أرسل كلمة المرور:',
        'password_saved': 'تم حفظ كلمة المرور. قم بحل الكابتشا: 22-21=?',
        'captcha_success': 'عظيم! تم التسجيل بنجاح. أهلاً بك!',
        'choose_action': 'اختر إجراءً:',
        'low_balance': 'الرصيد منخفض! يرجى الشحن أولاً.',
        'deducted': 'تم خصم {} رصيد. الرصيد الجديد: {}.',
        'balance': 'رصيدك الحالي: {} رصيد',
        'choose_method': 'اختر طريقة الشحن:',
        'ask_amount': 'أرسل المبلغ المراد شحنه:',
        'request_sent': 'تم إرسال طلب الشحن للمدير. يرجى الانتظار للموافقة.',
        'photo_sent': 'تم إرسال صورة الإثبات. سيتم تحديث رصيدك قريباً.',
        'wrong_captcha': 'خطأ! حاول مرة أخرى: 22-21=?',
        'too_many_attempts': 'لم نتمكن من التحقق. حاول مرة أخرى لاحقاً.',
        'username_taken': 'اسم المستخدم محجوز بالفعل. جرب اسماً آخر.',
        'use_buttons': 'الرجاء استخدام الأزرار.',
        'phone_received': 'تم شراء رقم مؤقت: {}',
        'error': 'حدث خطأ: {}',
        'admin_welcome': 'أهلاً بك أيها المدير! لوحة التحكم:',
        'admin_stats': 'إجمالي المستخدمين: {}',
        'edit_addresses_prompt': '📝 اختر عنوان الشحن الذي تريد تعديله:',
        'edit_price': '⚙️ تعديل سعر الرقم (الحالي: {}): أرسل القيمة الجديدة',
        'price_updated': 'تم تحديث سعر الرقم إلى: {}',
        'address_updated': '✅ تم تحديث عنوان **{}** إلى: {}',
        'requests_list': 'طلبات الشحن المُعلّقة:\n{}',
        'approval_notification': 'تمت الموافقة على طلب الشحن الخاص بك! تم تحديث رصيدك.',
        'rejection_notification': 'تم رفض طلب الشحن الخاص بك. تواصل مع الدعم.',
        'no_phone': 'يرجى شراء رقم مؤقت أولاً.',
        'no_sms': 'لم يتم العثور على رسالة. تم إضافة الرقم للقائمة السوداء.',
        'searching': '🔎 جارٍ البحث عن الكود... قد يستغرق الأمر دقيقة.',
        'access_denied': '❌ الوصول مرفوض.'
    }

# ----------------------------------------
# 3. لوحات المفاتيح (Keyboards)
# ----------------------------------------

def get_main_keyboard():
    """Keyboard for normal user actions."""
    keyboard = [
        [KeyboardButton("🔑 Buy a Temp Number")],
        [KeyboardButton("💰 My Balance"), KeyboardButton("💳 Charge My Account")],
        [KeyboardButton("✉️ Get Code")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def get_charge_keyboard():
    """Keyboard for selecting recharge method."""
    keyboard = [
        [KeyboardButton("Sham Cash (S.P)"), KeyboardButton("Sham Cash (USD)")],
        [KeyboardButton("USDT (BEP20)"), KeyboardButton("Syriatel Cash")],
        [KeyboardButton("Back")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def get_admin_keyboard():
    """Keyboard for admin control panel."""
    keyboard = [
        [KeyboardButton("📊 Stats"), KeyboardButton("⚙️ Edit Phone Price")],
        [KeyboardButton("📝 Edit Recharge Addresses")],
        [KeyboardButton("📋 Recharge Requests")],
        [KeyboardButton("Back")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

# ----------------------------------------
# 4. دوال Supabase والمساعدات
# ----------------------------------------

def is_registered(user_id):
    """Checks if a user is registered in the database."""
    try:
        data = supabase.table('users').select('user_id').eq('user_id', user_id).execute()
        return len(data.data) > 0
    except Exception as e:
        logger.error(f"DB registration check error: {e}")
        return False

async def get_user_balance(user_id):
    """Fetches the current balance of a user."""
    try:
        data = supabase.table('users').select('balance').eq('user_id', user_id).execute()
        return float(data.data[0]['balance']) if data.data else 0.0
    except Exception as e:
        logger.error(f"DB balance fetch error: {e}")
        return 0.0

def get_phone_price():
    """Fetches the current phone price from settings."""
    try:
        data = supabase.table('settings').select('value').eq('key', 'phone_price').execute()
        return float(data.data[0]['value']) if data.data else 5.0
    except Exception as e:
        logger.error(f"DB price fetch error: {e}")
        return 5.0

def get_recharge_address(method):
    """Fetches the recharge address based on method name."""
    # Convert button text to DB key
    key = method.lower().replace(' ', '_').replace('(s.p)', 'sp').replace('(usd)', 'usd').replace('(bep20)', 'bep20')
    try:
        data = supabase.table('settings').select('value').eq('key', key).execute()
        return data.data[0]['value'] if data.data else 'Not set'
    except Exception as e:
        logger.error(f"DB address fetch error: {e}")
        return 'Not set'

def get_recharge_message(method, address):
    """Formats the recharge message for the user."""
    return f"🏦 طريقة الشحن: **{method}**\n\nأرسل المبلغ إلى:\n`{address}`\n\nالرجاء **إرسال لقطة شاشة/صورة** لعملية التحويل لإتمام الطلب."

# ... (باقي الدوال المساعدة مثل get_pending_requests, format_requests, get_requests_keyboard)

# ----------------------------------------
# 5. دوال API
# ----------------------------------------

def make_request(endpoint, params=None):
    """Standardized API request to durianrcs.com."""
    if params is None:
        params = {}
    params.update({'name': USERNAME, 'ApiKey': API_KEY, 'pid': PID, 'serial': SERIAL})
    if endpoint in ["getMobile", "getMobileCode"]:
        params.update({'cuy': COUNTRY, 'num': NUM_COUNT})
    try:
        response = requests.get(f"{BASE_URL}/{endpoint}", params=params, timeout=30)
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"API request error to {endpoint}: {e}")
        return {"code": 500, "msg": "Internal API Error"}
    except Exception as e:
        logger.error(f"General API error: {e}")
        return {"code": 500, "msg": "General Error"}

async def get_phone(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Requests and displays a new temporary phone number."""
    data = make_request("getMobile")
    if data.get("code") == 200 and data.get("data"):
        phone = data["data"][0] if isinstance(data["data"], list) else data["data"]
        context.user_data['last_phone'] = phone
        await update.message.reply_text(get_messages()['phone_received'].format(phone))
    else:
        await update.message.reply_text(get_messages()['error'].format(data.get('msg', 'Unknown Error')))

async def get_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Waits and fetches the SMS code for the last purchased number."""
    phone = context.user_data.get('last_phone')
    if not phone:
        await update.message.reply_text(get_messages()['no_phone'])
        return

    status_message = await update.message.reply_text(get_messages()['searching'])
    
    # Wait for up to 300 seconds (20 iterations * 15 seconds)
    for _ in range(20):
        time.sleep(15)
        data = make_request("getMsg", {'pn': phone})
        
        if data.get("code") == 200 and data.get("data"):
            code = data["data"][0] if isinstance(data["data"], list) else data["data"]
            await status_message.edit_text(f"🎉 **Code Received!**\n\nالكود هو: `{code}`")
            return
        
        # 407: No code yet, 908: Wait more, 405: Phone not found/expired
        elif data.get("code") not in [407, 908, 405]:
            # Log unexpected API error
            logger.warning(f"Unexpected API response for getMsg: {data}")

    # If loop finishes without success
    await status_message.edit_text(get_messages()['no_sms'])
    add_to_blacklist(phone)

def add_to_blacklist(phone):
    """Adds a phone number to the API blacklist."""
    make_request("addBlack", {'pn': phone})
    
# ----------------------------------------
# 6. دوال التعامل مع البوت (Handlers)
# ----------------------------------------

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Displays the main menu keyboard."""
    text = get_messages()['choose_action']
    keyboard = get_main_keyboard()
    await update.message.reply_text(text, reply_markup=keyboard)

async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Displays the admin control panel."""
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        await update.message.reply_text(get_messages()['access_denied'])
        return
    text = get_messages()['admin_welcome']
    keyboard = get_admin_keyboard()
    await update.message.reply_text(text, reply_markup=keyboard)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handles the /start command (registration or main menu)."""
    user_id = update.effective_user.id
    if user_id == ADMIN_ID:
        await admin_command(update, context)
        return ConversationHandler.END
    
    if is_registered(user_id):
        await show_main_menu(update, context)
        return ConversationHandler.END # If already registered, exit ConversationHandler
    else:
        await update.message.reply_text(get_messages()['welcome'])
        await update.message.reply_text(get_messages()['ask_username'])
        return USERNAME_STATE

# --- Registration Handlers ---
async def username_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # ... (كود username_handler الحالي) ...
    username = update.message.text.strip()
    try:
        data = supabase.table('users').select('*').eq('username', username).execute()
        if len(data.data) > 0:
            await update.message.reply_text(get_messages()['username_taken'])
            return USERNAME_STATE
        context.user_data['temp_username'] = username
    except Exception as e:
        logger.error(f"DB username check error: {e}")
        await update.message.reply_text(get_messages()['error'].format("Checking username. Try again."))
        return USERNAME_STATE
    await update.message.reply_text(get_messages()['username_saved'])
    return PASSWORD_STATE

async def password_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # ... (كود password_handler الحالي) ...
    password = update.message.text.strip()
    user_id = update.effective_user.id
    username = context.user_data.get('temp_username')
    if not username:
        await update.message.reply_text(get_messages()['error'].format("Session expired. Start over with /start."))
        return ConversationHandler.END
    
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode('utf-8')
    try:
        supabase.table('users').insert({
            'user_id': user_id,
            'username': username,
            'password': hashed,
            'balance': 0.00,
            'attempts': 0
        }).execute()
        del context.user_data['temp_username']
    except Exception as e:
        logger.error(f"DB insert error: {e}")
        await update.message.reply_text(get_messages()['error'].format("Saving user. Try again."))
        return PASSWORD_STATE
    await update.message.reply_text(get_messages()['password_saved'])
    return CAPTCHA_STATE

async def captcha_check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # ... (كود captcha_check الحالي) ...
    answer = update.message.text.strip()
    user_id = update.effective_user.id
    if answer == "1":
        try:
            supabase.table('users').update({'attempts': 0}).eq('user_id', user_id).execute()
        except Exception as e:
            logger.error(f"DB CAPTCHA reset error: {e}")
        await update.message.reply_text(get_messages()['captcha_success'])
        await show_main_menu(update, context)
        return ConversationHandler.END
    else:
        try:
            data = supabase.table('users').select('attempts').eq('user_id', user_id).execute()
            attempts = (data.data[0]['attempts'] + 1) if data.data else 1
            supabase.table('users').update({'attempts': attempts}).eq('user_id', user_id).execute()
        except Exception as e:
            logger.error(f"DB CAPTCHA update error: {e}")
        if attempts >= 3:
            await update.message.reply_text(get_messages()['too_many_attempts'])
            return ConversationHandler.END
        else:
            await update.message.reply_text(get_messages()['wrong_captcha'])
            return CAPTCHA_STATE

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Cancels any ongoing conversation."""
    await update.message.reply_text("تم إلغاء العملية.", reply_markup=get_main_keyboard())
    return ConversationHandler.END

# --- Main Button Handler (User & Admin Logic) ---
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text.strip()
    user_id = update.effective_user.id
    
    # Ignore commands
    if text.startswith('/'):
        return
        
    # Check for 'Back' button universally for simple navigation
    if text == "Back":
        # Check if Admin is in a special editing state
        if user_id == ADMIN_ID and 'admin_editing' in context.user_data:
            context.user_data.pop('admin_editing', None)
            context.user_data.pop('admin_editing_key', None)
            context.user_data.pop('editing', None)
            await admin_command(update, context)
            return

        # Default back to main user menu
        await show_main_menu(update, context)
        return

    # ------------------ منطق الأدمن (ADMIN LOGIC) ------------------
    if user_id == ADMIN_ID:
        
        # --- Handle Admin Editing States ---
        current_state = context.user_data.get('admin_editing')
        
        # 1. المرحلة 3: استقبال قيمة العنوان الجديد وحفظها
        if current_state == 'address_value_input':
            new_address = text
            key_name = context.user_data.pop('admin_editing_key')
            db_key = key_name.lower().replace(' ', '_').replace('(s.p)', 'sp').replace('(usd)', 'usd').replace('(bep20)', 'bep20')
            
            try:
                # Update or Insert logic for settings table
                result = supabase.table('settings').update({'value': new_address}).eq('key', db_key).execute()
                if not result.data: 
                    supabase.table('settings').insert({'key': db_key, 'value': new_address}).execute()
                    
                await update.message.reply_text(get_messages()['address_updated'].format(key_name, new_address))
            except Exception as e:
                logger.error(f"DB address update error: {e}")
                await update.message.reply_text(get_messages()['error'].format("saving the address."))
                
            context.user_data.pop('admin_editing', None)
            await admin_command(update, context)
            return

        # 2. المرحلة 2: استقبال قيمة السعر الجديد وحفظها (Editing Price)
        elif context.user_data.get('editing') == 'price':
            try:
                new_price = float(text)
                result = supabase.table('settings').update({'value': str(new_price)}).eq('key', 'phone_price').execute()
                if not result.data:
                    supabase.table('settings').insert({'key': 'phone_price', 'value': str(new_price)}).execute()
                    
                await update.message.reply_text(get_messages()['price_updated'].format(new_price))
            except ValueError:
                await update.message.reply_text("❌ قيمة غير صالحة. الرجاء إرسال رقم.")
            except Exception as e:
                logger.error(f"DB price update error: {e}")
                await update.message.reply_text(get_messages()['error'].format("saving the price."))
            
            context.user_data.pop('editing', None)
            await admin_command(update, context)
            return
            
        # 3. المرحلة 1: اختيار نوع العنوان للتعديل (Address Type Selection)
        elif current_state == 'address_type_selection':
            if text in ["Sham Cash (S.P)", "Sham Cash (USD)", "USDT (BEP20)", "Syriatel Cash"]:
                context.user_data['admin_editing_key'] = text
                context.user_data['admin_editing'] = 'address_value_input'
                await update.message.reply_text(f"✅ أرسل **العنوان الجديد** لـ: **{text}**")
            else:
                await update.message.reply_text("الرجاء اختيار نوع العنوان من الأزرار.")
            return

        # --- Handle Admin Menu Buttons ---
        elif text == "📊 Stats":
            count = len(supabase.table('users').select('*').execute().data)
            await update.message.reply_text(get_messages()['admin_stats'].format(count))
            
        elif text == "📝 Edit Recharge Addresses":
            # Start the address editing process
            address_keyboard = get_charge_keyboard()
            await update.message.reply_text(
                get_messages()['edit_addresses_prompt'], 
                reply_markup=address_keyboard
            )
            context.user_data['admin_editing'] = 'address_type_selection'
            
        elif text == "⚙️ Edit Phone Price":
            price = get_phone_price()
            await update.message.reply_text(get_messages()['edit_price'].format(price))
            context.user_data['editing'] = 'price'
            
        elif text == "📋 Recharge Requests":
            # ... (منطق عرض الطلبات) ...
            await update.message.reply_text("عرض طلبات الشحن قيد الانتظار...") 
            # (يجب إضافة منطق عرض ومعالجة الطلبات هنا)
            
        # --- Fallback for Admin (After handling all cases) ---
        else:
            await update.message.reply_text(get_messages()['use_buttons'])
            
    # ------------------ منطق المستخدم (USER LOGIC) ------------------
    else:
        # User actions must be handled only if not in an admin state or registration conversation
        
        if text == "🔑 Buy a Temp Number":
            balance = await get_user_balance(user_id)
            price = get_phone_price()
            if balance < price:
                await update.message.reply_text(get_messages()['low_balance'])
                return
            await get_phone(update, context)
            new_balance = balance - price
            supabase.table('users').update({'balance': new_balance}).eq('user_id', user_id).execute()
            await update.message.reply_text(get_messages()['deducted'].format(price, new_balance))

        elif text == "💰 My Balance":
            balance = await get_user_balance(user_id)
            await update.message.reply_text(get_messages()['balance'].format(balance))

        elif text == "💳 Charge My Account":
            keyboard = get_charge_keyboard()
            await update.message.reply_text(get_messages()['choose_method'], reply_markup=keyboard)

        elif text == "✉️ Get Code":
            await get_code(update, context)

        elif text in ["Sham Cash (S.P)", "Sham Cash (USD)", "USDT (BEP20)", "Syriatel Cash"]:
            address = get_recharge_address(text)
            msg = get_recharge_message(text, address)
            await update.message.reply_text(msg)
            context.user_data['payment_type'] = text
            await update.message.reply_text(get_messages()['ask_amount'])

        elif 'payment_type' in context.user_data and text.isdigit():
            # Handle amount input after choosing payment type
            amount = float(text)
            payment_type = context.user_data['payment_type']
            
            # Save request to DB
            supabase.table('recharge_requests').insert({
                'user_id': user_id,
                'payment_type': payment_type,
                'amount': amount,
                'status': 'pending'
            }).execute()
            
            await update.message.reply_text(get_messages()['request_sent'])
            
            # Send notification to admin (optional, for advanced implementation)
            # await context.bot.send_message(ADMIN_ID, f"New recharge request from {user_id} for {amount} {payment_type}.")

        else:
            await update.message.reply_text(get_messages()['use_buttons'])

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # ... (كود handle_photo الحالي) ...
    user_id = update.effective_user.id
    if 'payment_type' not in context.user_data:
        await update.message.reply_text("يرجى اختيار طريقة الشحن وإرسال المبلغ أولاً.")
        return
        
    # Get the latest photo
    photo = update.message.photo[-1]
    
    # Send a copy to the admin
    caption_text = f"🚨 **إثبات شحن جديد** 🚨\n\nمن المستخدم ID: `{user_id}`"
    try:
        await context.bot.send_photo(ADMIN_ID, photo, caption=caption_text)
        await update.message.reply_text(get_messages()['photo_sent'])
    except Exception as e:
        logger.error(f"Error sending photo to admin: {e}")
        await update.message.reply_text("حدث خطأ أثناء إرسال الصورة للمدير. يرجى المحاولة لاحقاً.")

    context.user_data.pop('payment_type', None)
    await show_main_menu(update, context)


def main():
    """Starts the bot using webhook."""
    # Ensure all required environment variables are set before proceeding
    if not all([BOT_TOKEN, os.getenv('RENDER_EXTERNAL_HOSTNAME')]):
        logger.error("Missing BOT_TOKEN or RENDER_EXTERNAL_HOSTNAME.")
        return

    app = Application.builder().token(BOT_TOKEN).build()

    # Conversation Handler for Registration
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={
            USERNAME_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, username_handler)],
            PASSWORD_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, password_handler)],
            CAPTCHA_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, captcha_check)],
        },
        fallbacks=[CommandHandler('cancel', cancel)],
    )

    app.add_handler(conv_handler)
    app.add_handler(CommandHandler("admin", admin_command))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, button_handler)) # General text/button handler

    # Webhook Setup
    PORT = int(os.getenv('PORT', 10000))
    HOSTNAME = os.getenv('RENDER_EXTERNAL_HOSTNAME')
    WEBHOOK_URL = f"https://{HOSTNAME}/{BOT_TOKEN}"

    app.bot.set_webhook(url=WEBHOOK_URL)
    logger.info(f"Webhook URL set: {WEBHOOK_URL}")

    app.run_webhook(
        listen="0.0.0.0",
        port=PORT,
        url_path=BOT_TOKEN,
        webhook_url=WEBHOOK_URL
    )

if __name__ == "__main__":
    main()
