# smsbot2_interactive_v2.py
# -*- coding: utf-8 -*-

import logging
import time
import os
from urllib.parse import quote_plus, unquote_plus

import requests
import bcrypt
from dotenv import load_dotenv

# Telegram (python-telegram-bot v20+)
from telegram import (
    Update, ReplyKeyboardMarkup, KeyboardButton,
    InlineKeyboardButton, InlineKeyboardMarkup
)
from telegram.ext import (
    Application, CommandHandler, MessageHandler, filters,
    ContextTypes, ConversationHandler, CallbackQueryHandler
)

# Supabase
from supabase import create_client, Client

# =========================
# 1) الإعدادات العامة
# =========================

load_dotenv()

USERNAME = os.getenv('USERNAME')
API_KEY = os.getenv('API_KEY')
BOT_TOKEN = os.getenv('BOT_TOKEN')
COUNTRY = os.getenv('COUNTRY', 'us')
NUM_COUNT = int(os.getenv('NUM_COUNT', 1))
SERIAL = int(os.getenv('SERIAL', 2))
ADMIN_ID = int(os.getenv('ADMIN_ID', 0))

SUPABASE_URL = os.getenv('SUPABASE_URL')
SUPABASE_KEY = os.getenv('SUPABASE_KEY')

if not all([BOT_TOKEN, USERNAME, API_KEY, SUPABASE_URL, SUPABASE_KEY, ADMIN_ID]):
    raise ValueError("❌ Missing required environment variables!")

# Supabase client
try:
    supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
except Exception as e:
    raise RuntimeError(f"Failed to create Supabase client: {e}")

BASE_URL = "https://api.durianrcs.com/out/ext_api"

# لوجر
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# =========================
# 2) ثوابت الحوارات
# =========================
USERNAME_STATE, PASSWORD_STATE, CAPTCHA_STATE = range(3)
WAITING_TRANSFER_ID = 11   # لسيرياتيل: ننتظر رقم العملية
WAITING_PHOTO = 12         # لباقي الطرق: ننتظر صورة الإشعار
WAITING_AMOUNT = 13        # في الحالتين ننتظر المبلغ لاحقاً

# =========================
# 3) الخدمات ↔ PID
# =========================
SERVICE_TO_PID = {
    "📧 Gmail 1": "0097",
    "📧 Gmail 2": "0098",
    "🪟 Microsoft": "0241",
    "💰 Swagbucks": "0652",
    "💌 InboxDollars": "1072",
    "📊 Ipsos": "2397",
    "🟢 ATTAPOL": "1998",
}

# =========================
# 4) الرسائل (مرحة + موجزة)
# =========================
def M():
    return {
        'welcome': '👋 أهلاً! خلّينا نبدأ تسجيل سريع:',
        'ask_username': '📎 أرسل اسم المستخدم الذي تريده:',
        'username_saved': '✅ تمام! الآن أرسل كلمة المرور:',
        'password_saved': '🔐 ممتاز. حلّ الكابتشا: 22 - 21 = ؟',
        'captcha_success': '🎉 تم التسجيل بنجاح — أهلاً بك!',
        'choose_action': '✨ ماذا تحب أن تفعل الآن؟ استخدم الأزرار بالأسفل:',
        'low_balance': '⚠️ رصيدك غير كافٍ — اشحن أولاً لو سمحت.',
        'deducted': '💸 تم خصم {}. رصيدك الحالي: {}.',
        'balance': '💰 رصيدك الحالي: {}',
        'account': '👤 معلومات حسابك:\n\n• ID: `{}`\n• الرصيد: **{}**',
        'choose_method': '🔁 اختر طريقة الشحن:',
        'ask_amount': '📥 أرسل **المبلغ** الذي شحنتَه (مثال: 50 أو 10.5):',
        'request_sent': '✅ تم استلام طلبك رقم **{}**.\nسيتم مراجعته قريبًا وإبلاغك بالنتيجة.',
        'photo_sent': '🖼️ استلمت صورة الإشعار. الآن أرسل المبلغ.',
        'wrong_captcha': '❌ الإجابة غير صحيحة — جرّب مجددًا: 22 - 21 = ؟',
        'too_many_attempts': '⌛ كثير محاولات خاطئة — جرّب لاحقًا.',
        'username_taken': '🚫 الاسم محجوز — اختر اسمًا آخر.',
        'use_buttons': '🔘 استخدم الأزرار من فضلك.',
        'phone_received': '📲 رقمك المؤقت: {}',
        'error': '⚠️ حدث خطأ: {}',
        'admin_welcome': '🎛️ **لوحة المدير** — اختر إجراءً:',
        'admin_stats': '📈 **إحصائيات**:\n• المستخدمون: {}\n• طلبات شحن آخر 24 ساعة: {}',
        'edit_addresses_prompt': '📝 اختر طريقة لتعديل عنوان الشحن:',
        'edit_price': '⚙️ أرسل السعر الجديد للرقم (الحالي: {}):',
        'price_updated': '✅ تم تحديث السعر إلى: {}',
        'address_updated': '✅ تم تحديث عنوان **{}** إلى: {}',
        'approval_notification': '✅ تمت الموافقة! أُضيف **{}** لرصيدك. رصيدك الآن: **{}**.',
        'rejection_notification': '❌ تم رفض الطلب. راسل الدعم.',
        'no_phone': '❗ لم تشترِ رقمًا بعد. اختر "🔑 شراء رقم مؤقت".',
        'no_sms': '⏳ لم يصل الكود حتى الآن.',
        'searching': '🔎 جارٍ البحث عن رسالة التحقق (حتى 60 ثانية)...',
        'access_denied': '⛔ وصول مرفوض.',
        'choose_country': '🌍 اختر الدولة لشراء الرقم المؤقت:',
        'country_selected': '✅ اخترت: {} — اختر الخدمة الآن:',
        'choose_service': '📱 اختر الخدمة:',
        'service_selected': '✅ تم اختيار: {} — جارٍ شراء الرقم...',
        'next_page': 'التالي ➡️',
        'prev_page': '⬅️ السابق',
        'service_page_info': 'صفحة {} من {}',
        'requests_list': '📋 **طلبات الشحن قيد الانتظار**:\n\n',
        'buy_phone_prompt': '🔄 نشتري لك رقمًا مناسبًا الآن...',
        'get_code_tip': '⏳ إذا تأخر الكود، يمكنك إضافة الرقم للبلاك-ليست من الزر.',
        'ask_transfer_id': '📞 **سيرياتيل كاش**\nأرسل **رقم عملية التحويل** الآن:',
        'ask_amount_syp': '💵 أرسل **المبلغ بالليرة السورية (SYP)** الذي أرسلته (مثال: 50000):',
        'usd_rate_prompt': '💵 أرسل **سعر الدولار بالليرة السورية** (مثال: 10000):',
        'usd_rate_updated': '✅ تم تحديث سعر الدولار إلى: **{} SYP**',
    }

# =========================
# 5) لوحات المفاتيح
# =========================
def kb_main():
    keyboard = [
        [KeyboardButton("🔑 شراء رقم مؤقت")],
        [KeyboardButton("👤 حسابي"), KeyboardButton("💳 شحن الحساب")],
        [KeyboardButton("✉️ الحصول على الكود")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def kb_countries():
    keyboard = [
        [KeyboardButton("🇺🇸 USA")],
        [KeyboardButton("رجوع")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def kb_charge():
    keyboard = [
        [KeyboardButton("شام كاش (ل.س)"), KeyboardButton("شام كاش (دولار)")],
        [KeyboardButton("USDT (BEP20)"), KeyboardButton("سيرياتيل كاش")],
        [KeyboardButton("رجوع")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def kb_admin():
    keyboard = [
        [KeyboardButton("📊 الإحصائيات"), KeyboardButton("⚙️ تعديل سعر الرقم")],
        [KeyboardButton("📝 تعديل عناوين الشحن"), KeyboardButton("📋 طلبات الشحن")],
        [KeyboardButton("➕ إضافة رصيد يدوي"), KeyboardButton("➖ خصم رصيد يدوي")],
        [KeyboardButton("💵 سعر الدولار"), KeyboardButton("رجوع")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def kb_admin_services():
    return ReplyKeyboardMarkup([
        [KeyboardButton("تفعيل/تعطيل الخدمة"), KeyboardButton("تعديل الإعدادات")],
        [KeyboardButton("رجوع")]
    ], resize_keyboard=True)

def kb_services_page(context: ContextTypes.DEFAULT_TYPE):
    services = list(SERVICE_TO_PID.keys())
    page = context.user_data.get('service_page', 0)
    items = 6

    if len(services) <= items:
        keyboard = [[KeyboardButton(s)] for s in services]
        keyboard.append([KeyboardButton("رجوع")])
        markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
        return markup, None

    start = page * items
    end = min(start + items, len(services))
    page_services = services[start:end]
    keyboard = [[KeyboardButton(s)] for s in page_services]

    nav = []
    if page > 0: nav.append(KeyboardButton(M()['prev_page']))
    if end < len(services): nav.append(KeyboardButton(M()['next_page']))
    if nav: keyboard.append(nav)

    keyboard.append([KeyboardButton("رجوع")])
    markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    page_info = M()['service_page_info'].format(page + 1, (len(services) + items - 1) // items)
    return markup, page_info

# =========================
# 6) DB Helpers
# =========================
def is_registered(user_id: int) -> bool:
    try:
        data = supabase.table('users').select('user_id').eq('user_id', user_id).execute()
        return bool(data.data)
    except Exception as e:
        logger.error(f"is_registered error: {e}")
        return False

async def get_user_balance(user_id: int) -> float:
    try:
        data = supabase.table('users').select('balance').eq('user_id', user_id).execute()
        return float(data.data[0]['balance']) if data.data else 0.0
    except Exception as e:
        logger.error(f"get_user_balance error: {e}")
        return 0.0

async def update_user_balance(user_id: int, new_balance: float):
    try:
        supabase.table('users').update({'balance': new_balance}).eq('user_id', user_id).execute()
    except Exception as e:
        logger.error(f"update_user_balance error: {e}")

def get_phone_price() -> float:
    try:
        data = supabase.table('settings').select('value').eq('key', 'phone_price').execute()
        return float(data.data[0]['value']) if data.data else 5.0
    except Exception as e:
        logger.error(f"get_phone_price error: {e}")
        return 5.0

def get_recharge_address(method: str) -> str:
    key = method.lower().replace(' ', '_').replace('(ل.س)', 'sp').replace('(دولار)', 'usd').replace('(bep20)', 'bep20')
    try:
        data = supabase.table('settings').select('value').eq('key', key).execute()
        return data.data[0]['value'] if data.data else 'غير محدد'
    except Exception as e:
        logger.error(f"get_recharge_address error: {e}")
        return 'غير محدد'

def msg_recharge(method: str, address: str) -> str:
    return f"🏦 **طريقة الشحن:** {method}\n\nأرسل إلى:\n`{address}`\n\nثم أرسل **صورة إثبات الدفع** وبعدها **المبلغ**."

def next_recharge_id() -> int:
    try:
        data = supabase.table('settings').select('value').eq('key', 'recharge_id_sequence').execute()
        if data.data:
            last_id = int(data.data[0]['value'])
            nxt = last_id + 1
            supabase.table('settings').update({'value': str(nxt)}).eq('key', 'recharge_id_sequence').execute()
            return nxt
        else:
            initial = 2300
            supabase.table('settings').insert({'key': 'recharge_id_sequence', 'value': str(initial + 1)}).execute()
            return initial
    except Exception as e:
        logger.error(f"next_recharge_id error: {e}")
        return 990000 + int(time.time())

def get_usd_rate() -> float:
    """قراءة سعر الدولار (SYP per USD) من settings (key=usd_rate)."""
    try:
        data = supabase.table('settings').select('value').eq('key', 'usd_rate').execute()
        return float(data.data[0]['value']) if data.data else 10000.0
    except Exception as e:
        logger.error(f"get_usd_rate error: {e}")
        return 10000.0

def set_usd_rate(v: float):
    try:
        supabase.table('settings').upsert({'key': 'usd_rate', 'value': str(v)}, on_conflict='key').execute()
        return True
    except Exception as e:
        logger.error(f"set_usd_rate error: {e}")
        return False

# =========================
# 7) إرسال طلب الشحن للمدير
# =========================
async def send_recharge_request_to_admin(
    update: Update, context: ContextTypes.DEFAULT_TYPE,
    amount: float, recharge_type: str,
    transfer_id: str | None = None, photo_file_id: str | None = None
):
    req_id = next_recharge_id()
    user = update.effective_user

    try:
        supabase.table('recharge_requests').insert({
            'id': req_id,
            'user_id': user.id,
            'username': user.username or str(user.id),
            'payment_type': recharge_type,
            'amount': amount,  # ملاحظة: لسيرياتيل يكون SYP، للباقي USD
            'status': 'pending',
            'photo_file_id': photo_file_id,
            'transfer_id': transfer_id
        }).execute()
    except Exception as e:
        logger.error(f"insert recharge request error: {e}")
        await update.message.reply_text(M()['error'].format("حفظ الطلب بقاعدة البيانات"))
        return

    # رسالة للمدير
    src_info = f"رقم العملية: `{transfer_id}`" if transfer_id else ("صورة إثبات مرفقة." if photo_file_id else "—")
    admin_msg = (
        f"🚨 **طلب شحن جديد (ID: {req_id})**\n\n"
        f"• المستخدم: @{user.username or user.id} (`{user.id}`)\n"
        f"• الطريقة: **{recharge_type}**\n"
        f"• المبلغ: **{amount}**\n"
        f"• الإثبات: {src_info}\n\n"
        "راجِع الطلب ثم اختر الإجراء:"
    )
    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton("✅ موافقة", callback_data=f"req_approve_{req_id}"),
        InlineKeyboardButton("❌ رفض", callback_data=f"req_reject_{req_id}")
    ]])

    # إشعار للمستخدم
    try:
        if photo_file_id:
            await context.bot.send_photo(
                ADMIN_ID, photo=photo_file_id, caption=admin_msg, reply_markup=keyboard, parse_mode='Markdown'
            )
        else:
            await context.bot.send_message(ADMIN_ID, admin_msg, reply_markup=keyboard, parse_mode='Markdown')

        await update.message.reply_text(M()['request_sent'].format(req_id), parse_mode='Markdown')
    except Exception as e:
        logger.error(f"send to admin error: {e}")
        await update.message.reply_text(M()['error'].format("تعذّر إرسال الطلب للمدير"))

# =========================
# 8) API: شراء رقم/جلب كود (مع أزرار النسخ والبلاك-ليست)
# =========================
async def buy_temp_phone(update: Update, context: ContextTypes.DEFAULT_TYPE, country_code: str, service_pid: str):
    user_id = update.effective_user.id
    price = get_phone_price()
    balance = await get_user_balance(user_id)
    if balance < price:
        await update.message.reply_text(M()['low_balance'])
        return

    await update.message.reply_text(M()['buy_phone_prompt'])
    try:
        url = f"{BASE_URL}/getMobile"
        params = {
            'name': USERNAME, 'ApiKey': API_KEY,
            'cuy': country_code, 'pid': service_pid,
            'num': NUM_COUNT, 'noblack': 0,
            'serial': SERIAL, 'secret_key': 'null', 'vip': 'null'
        }
        logger.info(f"getMobile params: {params}")
        resp = requests.get(url, params=params, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        logger.info(f"getMobile response: {data}")

        if data.get("code") != 200:
            raise ValueError(f"API Error {data.get('code')}: {data.get('msg')}")

        phone = data.get("data")
        if not phone:
            raise ValueError("لم يتم استلام رقم")

        # خصم الرصيد
        new_balance = balance - price
        await update_user_balance(user_id, new_balance)
        context.user_data['temp_phone'] = phone
        context.user_data['temp_pid'] = service_pid

        copy_label = "📋 انسخ الرقم (يُدخل في الحقل)"
        blacklist_label = "🚫 إضافة للبلاك-ليست"

        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton(copy_label, switch_inline_query_current_chat=str(phone)),
                InlineKeyboardButton(blacklist_label, callback_data=f"blacklist_{quote_plus(str(phone))}")
            ],
            [
                InlineKeyboardButton("🔄 أعد شراء رقم", callback_data=f"repurchase_{service_pid}")
            ]
        ])

        await update.message.reply_text(
            f"📲 **رقمك المؤقت:** `{phone}`\n\n{M()['get_code_tip']}",
            reply_markup=keyboard, parse_mode='Markdown'
        )
        await update.message.reply_text(M()['deducted'].format(price, new_balance))

    except Exception as e:
        logger.error(f"buy_temp_phone error: {e}")
        await update.message.reply_text(M()['error'].format(f"شراء الرقم: {str(e)}"))

async def get_sms_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    phone = context.user_data.get('temp_phone')
    service_pid = context.user_data.get('temp_pid')
    if not phone:
        await update.message.reply_text(M()['no_phone'])
        return

    await update.message.reply_text(M()['searching'])
    try:
        url = f"{BASE_URL}/getMsg"
        params = {
            'name': USERNAME, 'ApiKey': API_KEY,
            'pid': service_pid, 'pn': phone, 'serial': SERIAL
        }
        start = time.time()
        while time.time() - start < 60:
            resp = requests.get(url, params=params, timeout=15)
            resp.raise_for_status()
            data = resp.json()
            logger.info(f"getMsg response: {data}")

            if data.get("code") == 200:
                code = data.get("data")
                await update.message.reply_text(f"✅ الكود المستلم: `{code}`", parse_mode='Markdown')
                context.user_data.pop('temp_phone', None)
                context.user_data.pop('temp_pid', None)
                return
            elif data.get("code") in [908, 203]:
                time.sleep(5)
                continue
            else:
                raise ValueError(f"API Error {data.get('code')}: {data.get('msg')}")

        await update.message.reply_text(M()['no_sms'])
        # يمكن إضافة للبلاك-ليست تلقائيًا إن رغبت
    except Exception as e:
        logger.error(f"get_sms_code error: {e}")
        await update.message.reply_text(M()['error'].format(str(e)))

# =========================
# 9) التسجيل، ستارت، إلغاء
# =========================
def k_b(kb_func):
    return kb_func()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    user_id = update.effective_user.id
    if user_id == ADMIN_ID:
        await admin_panel(update, context)
        return ConversationHandler.END

    if is_registered(user_id):
        await show_main_menu(update, context)
        return ConversationHandler.END

    await update.message.reply_text(M()['welcome'])
    await update.message.reply_text(M()['ask_username'])
    return USERNAME_STATE

async def username_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    username = update.message.text.strip()
    try:
        exists = supabase.table('users').select('username').eq('username', username).execute()
        if exists.data:
            await update.message.reply_text(M()['username_taken'])
            return USERNAME_STATE

        context.user_data['reg_username'] = username
        await update.message.reply_text(M()['username_saved'])
        return PASSWORD_STATE
    except Exception as e:
        logger.error(f"username_handler error: {e}")
        await update.message.reply_text(M()['error'].format("التحقق من الاسم"))
        return USERNAME_STATE

async def password_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    password = update.message.text.strip()
    hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    context.user_data['reg_password'] = hashed
    await update.message.reply_text(M()['password_saved'])
    context.user_data['captcha_attempts'] = 0
    return CAPTCHA_STATE

async def captcha_check(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    if update.message.text.strip() == "1":
        user = update.effective_user
        try:
            supabase.table('users').insert({
                'user_id': user.id,
                'username': context.user_data['reg_username'],
                'password_hash': context.user_data['reg_password'],
                'balance': 0.0
            }).execute()
            await update.message.reply_text(M()['captcha_success'], reply_markup=k_b(kb_main))
            context.user_data.clear()
            return ConversationHandler.END
        except Exception as e:
            logger.error(f"captcha_check insert error: {e}")
            await update.message.reply_text(M()['error'].format("التسجيل"))
            return CAPTCHA_STATE
    else:
        context.user_data['captcha_attempts'] = context.user_data.get('captcha_attempts', 0) + 1
        if context.user_data['captcha_attempts'] >= 3:
            await update.message.reply_text(M()['too_many_attempts'], reply_markup=k_b(kb_main))
            context.user_data.clear()
            return ConversationHandler.END
        await update.message.reply_text(M()['wrong_captcha'])
        return CAPTCHA_STATE

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("🚫 تم إلغاء العملية.", reply_markup=k_b(kb_main))
    context.user_data.clear()
    return ConversationHandler.END

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(M()['choose_action'], reply_markup=k_b(kb_main))
    # تصفير حالات
    for k in ['recharge_step','recharge_type','temp_transfer','temp_photo',
              'waiting_country','selected_country','waiting_service','selected_service','service_page']:
        context.user_data.pop(k, None)

# =========================
# 10) لوحة المدير
# =========================
async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text(M()['access_denied'])
        return
    for k in ['editing', 'edit_key', 'edit_method', 'address_select']:
        context.user_data.pop(k, None)
    await update.message.reply_text(M()['admin_welcome'], reply_markup=k_b(kb_admin), parse_mode='Markdown')

async def show_admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        users = supabase.table('users').select('*').execute()
        user_count = len(users.data)
        try:
            since = int(time.time()) - 86400
            requests_today = supabase.table('recharge_requests').select('*').execute()
            req_count = len([r for r in requests_today.data or [] if r])
        except Exception:
            req_count = 0
        await update.message.reply_text(M()['admin_stats'].format(user_count, req_count), parse_mode='Markdown')
    except Exception as e:
        logger.error(f"show_admin_stats error: {e}")
        await update.message.reply_text(M()['error'].format("جلب الإحصائيات"))

async def manage_requests(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        pending = supabase.table('recharge_requests').select('*').eq('status', 'pending').execute()
        if not pending.data:
            await update.message.reply_text("لا توجد طلبات قيد الانتظار.")
            return
        text = M()['requests_list']
        for r in pending.data[:20]:
            text += f"• ID: {r['id']} | @{r.get('username','-')} | {r.get('payment_type','-')} | {r.get('amount','-')}\n"
        await update.message.reply_text(text, parse_mode='Markdown')
    except Exception as e:
        logger.error(f"manage_requests error: {e}")
        await update.message.reply_text(M()['error'].format("جلب الطلبات"))

async def manage_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🔒 **إدارة المستخدمين** — اختر إجراءً:",
        reply_markup=ReplyKeyboardMarkup([
            [KeyboardButton("➕ إضافة رصيد يدوي"), KeyboardButton("➖ خصم رصيد يدوي")],
            [KeyboardButton("عرض جميع المستخدمين"), KeyboardButton("رجوع")]
        ], resize_keyboard=True),
        parse_mode='Markdown'
    )

# =========================
# 11) تدفق الشحن + الصور (بحسب الوسيلة)
# =========================
async def start_recharge_flow(update: Update, context: ContextTypes.DEFAULT_TYPE, method: str, is_syriatel=False):
    context.user_data['recharge_type'] = method
    if is_syriatel:
        # منطق سيرياتيل: رقم العملية -> المبلغ (SYP) -> إرسال الطلب
        context.user_data['recharge_step'] = WAITING_TRANSFER_ID
        await update.message.reply_text(M()['ask_transfer_id'], parse_mode='Markdown')
    else:
        # باقي الوسائل: اطلب الصورة أولاً
        context.user_data['recharge_step'] = WAITING_PHOTO
        address = get_recharge_address(method)
        await update.message.reply_text(msg_recharge(method, address), parse_mode='Markdown')

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # هذه الخطوة تخص باقي الوسائل فقط
    if context.user_data.get('recharge_step') != WAITING_PHOTO:
        return
    photo_file_id = update.message.photo[-1].file_id
    context.user_data['temp_photo'] = photo_file_id
    context.user_data['recharge_step'] = WAITING_AMOUNT
    await update.message.reply_text(M()['photo_sent'])
    await update.message.reply_text(M()['ask_amount'], parse_mode='Markdown')

# =========================
# 12) Callback: موافقة/رفض المدير + بلاك-ليست/إعادة شراء + سعر الدولار
# =========================
async def admin_approval_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.from_user.id != ADMIN_ID:
        await q.edit_message_text("❌ ليس لديك صلاحية.")
        return

    parts = (q.data or "").split('_')
    if len(parts) != 3:
        await q.answer("بيانات غير صالحة.")
        return
    _, action, id_str = parts
    try:
        req_id = int(id_str)
    except ValueError:
        await q.answer("ID غير صالح.")
        return

    try:
        rec = supabase.table('recharge_requests').select('*').eq('id', req_id).execute().data
        if not rec or rec[0]['status'] != 'pending':
            await q.edit_message_text("⚠️ تمت معالجة هذا الطلب مسبقًا.")
            return
        req = rec[0]
        user_id = req['user_id']
        amount = float(req['amount'])
        payment_type = (req.get('payment_type') or "").strip()

        if action == 'approve':
            # إذا كانت سيرياتيل كاش: amount بالليرة السورية -> نحوله للدولار حسب usd_rate
            if "سيرياتيل" in payment_type:
                rate = get_usd_rate()  # SYP per USD
                usd_amount = amount / rate if rate > 0 else 0.0
                usd_amount = round(usd_amount, 6)
                current = await get_user_balance(user_id)
                newv = round(current + usd_amount, 6)
                await update_user_balance(user_id, newv)
                supabase.table('recharge_requests').update({'status': 'approved'}).eq('id', req_id).execute()
                await context.bot.send_message(user_id, M()['approval_notification'].format(usd_amount, newv))
            else:
                # باقي الوسائل: نعتبر amount بالدولار مباشرة
                current = await get_user_balance(user_id)
                newv = round(current + amount, 6)
                await update_user_balance(user_id, newv)
                supabase.table('recharge_requests').update({'status': 'approved'}).eq('id', req_id).execute()
                await context.bot.send_message(user_id, M()['approval_notification'].format(amount, newv))

            if q.message.photo:
                await q.edit_message_caption((q.message.caption or "") + "\n\n✅ تمت الموافقة.", parse_mode='Markdown')
            else:
                await q.edit_message_text((q.message.text or "") + "\n\n✅ تمت الموافقة.", parse_mode='Markdown')

        elif action == 'reject':
            supabase.table('recharge_requests').update({'status': 'rejected'}).eq('id', req_id).execute()
            await context.bot.send_message(user_id, M()['rejection_notification'])
            if q.message.photo:
                await q.edit_message_caption((q.message.caption or "") + "\n\n❌ تم الرفض.", parse_mode='Markdown')
            else:
                await q.edit_message_text((q.message.text or "") + "\n\n❌ تم الرفض.", parse_mode='Markdown')

    except Exception as e:
        logger.error(f"admin_approval_callback error: {e}")
        await q.edit_message_text(f"خطأ: {e}")

async def phone_inline_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """blacklist_<phone>, repurchase_<pid>"""
    q = update.callback_query
    await q.answer()
    data = q.data or ""
    user_id = q.from_user.id

    if data.startswith("blacklist_"):
        raw = data.split("blacklist_", 1)[1]
        phone = unquote_plus(raw)
        try:
            supabase.table('blacklisted_numbers').upsert({
                'phone': str(phone),
                'blocked_by': user_id,
                'blocked_at': int(time.time())
            }, on_conflict='phone').execute()
        except Exception as e:
            logger.error(f"blacklist upsert error: {e}")
            await q.edit_message_text(f"⚠️ خطأ أثناء إضافة {phone} للبلاك-ليست.")
            return
        base_text = (q.message.caption or q.message.text or "")
        suffix = "\n\n🚫 **تمت إضافة الرقم إلى البلاك-ليست.**"
        try:
            if q.message.photo:
                await q.edit_message_caption((base_text + suffix), parse_mode='Markdown')
            else:
                await q.edit_message_text((base_text + suffix), parse_mode='Markdown')
        except Exception:
            await context.bot.send_message(user_id, f"🚫 {phone} تمت إضافته إلى البلاك-ليست.")
        return

    if data.startswith("repurchase_"):
        pid = data.split("repurchase_", 1)[1]
        country_code = context.user_data.get('selected_country', COUNTRY or 'us')
        await context.bot.send_message(user_id, "🔁 نحاول شراء رقم جديد لنفس الخدمة...")
        class DummyMsg:
            def __init__(self, chat_id):
                self.chat_id = chat_id
            async def reply_text(self, text, **kw):
                await context.bot.send_message(chat_id=self.chat_id, text=text, **kw)
        dummy_update = Update(update.update_id, message=None)
        dummy_update.effective_user = q.from_user
        dummy_update.message = type("Msg", (), {"reply_text": DummyMsg(user_id).reply_text})()
        await buy_temp_phone(dummy_update, context, country_code, pid)
        return

    await q.answer("غير مدعوم.", show_alert=True)

# =========================
# 13) Unified Text/Button Handler
# =========================
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = (update.message.text or "").strip()
    user_id = update.effective_user.id
    msgs = M()

    # اختيار دولة
    if context.user_data.get('waiting_country'):
        if text == "🇺🇸 USA":
            context.user_data['selected_country'] = 'us'
            context.user_data.pop('waiting_country', None)
            markup, page_info = kb_services_page(context)
            await update.message.reply_text(
                msgs['country_selected'].format("USA") + (f"\n{page_info}" if page_info else ""),
                reply_markup=markup, parse_mode='Markdown'
            )
            context.user_data['waiting_service'] = True
            return
        if text == "رجوع":
            context.user_data.pop('waiting_country', None)
            await show_main_menu(update, context)
            return
        await update.message.reply_text(msgs['use_buttons'])
        return

    # اختيار خدمة
    if context.user_data.get('waiting_service'):
        services = list(SERVICE_TO_PID.keys())
        if text in [msgs['next_page'], msgs['prev_page']]:
            page = context.user_data.get('service_page', 0)
            items = 6
            if text == msgs['next_page'] and (page + 1) * items < len(services):
                context.user_data['service_page'] = page + 1
            elif text == msgs['prev_page'] and page > 0:
                context.user_data['service_page'] = page - 1
            markup, page_info = kb_services_page(context)
            await update.message.reply_text(
                msgs['choose_service'] + (f"\n{page_info}" if page_info else ""),
                reply_markup=markup, parse_mode='Markdown'
            )
            return

        pid = SERVICE_TO_PID.get(text)
        if pid:
            context.user_data['selected_service'] = text
            context.user_data.pop('waiting_service', None)
            await update.message.reply_text(msgs['service_selected'].format(text), parse_mode='Markdown')
            cc = context.user_data.get('selected_country', COUNTRY or 'us')
            await buy_temp_phone(update, context, cc, pid)
            for k in ['selected_country', 'selected_service', 'service_page']:
                context.user_data.pop(k, None)
            return

        if text == "رجوع":
            for k in ['waiting_service', 'selected_country', 'service_page']:
                context.user_data.pop(k, None)
            await show_main_menu(update, context)
            return

        await update.message.reply_text(msgs['use_buttons'])
        return

    # حالات إدارية خاصة
    if user_id == ADMIN_ID:
        editing = context.user_data.get('editing')
        if editing == 'price':
            try:
                new_price = float(text)
                supabase.table('settings').upsert({'key': 'phone_price', 'value': str(new_price)}, on_conflict='key').execute()
                await update.message.reply_text(msgs['price_updated'].format(new_price))
                context.user_data.pop('editing', None)
                await admin_panel(update, context)
            except ValueError:
                await update.message.reply_text("❌ قيمة غير صالحة. أرسل رقمًا.")
            return
        elif editing == 'address':
            key = context.user_data.pop('edit_key', None)
            method = context.user_data.pop('edit_method', None)
            try:
                if key:
                    supabase.table('settings').upsert({'key': key, 'value': text}, on_conflict='key').execute()
                    await update.message.reply_text(msgs['address_updated'].format(method, text))
            except Exception as e:
                logger.error(f"address update error: {e}")
                await update.message.reply_text(msgs['error'].format("تحديث العنوان"))
            context.user_data.pop('editing', None)
            await admin_panel(update, context)
            return
        elif editing == 'ban_user':
            try:
                ban_id = int(text)
                supabase.table('users').update({'banned': True}).eq('user_id', ban_id).execute()
                await update.message.reply_text(f"✅ حُظر المستخدم {ban_id}.")
            except ValueError:
                await update.message.reply_text("❌ ID غير صالح.")
            context.user_data.pop('editing', None)
            await admin_panel(update, context)
            return
        elif editing == 'add_balance':
            try:
                parts = text.split()
                uid = int(parts[0]); amount = float(parts[1])
                current = await get_user_balance(uid)
                newv = round(current + amount, 6)
                await update_user_balance(uid, newv)
                await update.message.reply_text(f"✅ تمت إضافة {amount} للمستخدم {uid}. الرصيد الجديد: {newv}.")
            except (ValueError, IndexError):
                await update.message.reply_text("❌ صيغة خاطئة. أرسل: ID المبلغ")
            context.user_data.pop('editing', None)
            await admin_panel(update, context)
            return
        elif editing == 'deduct_balance':
            try:
                parts = text.split()
                uid = int(parts[0]); amount = float(parts[1])
                current = await get_user_balance(uid)
                newv = round(max(0.0, current - amount), 6)
                await update_user_balance(uid, newv)
                await update.message.reply_text(f"✅ تم خصم {amount} من المستخدم {uid}. الرصيد الجديد: {newv}.")
            except (ValueError, IndexError):
                await update.message.reply_text("❌ صيغة خاطئة. أرسل: ID المبلغ")
            context.user_data.pop('editing', None)
            await admin_panel(update, context)
            return
        elif editing == 'usd_rate':
            try:
                rate = float(text)
                if rate <= 0: raise ValueError()
                ok = set_usd_rate(rate)
                if ok:
                    await update.message.reply_text(M()['usd_rate_updated'].format(rate), parse_mode='Markdown')
                else:
                    await update.message.reply_text(M()['error'].format("حفظ سعر الدولار"))
            except ValueError:
                await update.message.reply_text("❌ قيمة غير صالحة. أرسل رقمًا أكبر من 0.")
            context.user_data.pop('editing', None)
            await admin_panel(update, context)
            return

    # تدفق المستخدم العادي في الشحن (حسب الخطوات)
    step = context.user_data.get('recharge_step')
    if step == WAITING_TRANSFER_ID:
        # للسيرياتيل: أخذ رقم العملية، ثم نطلب المبلغ بالليرة
        context.user_data['temp_transfer'] = text
        context.user_data['recharge_step'] = WAITING_AMOUNT
        await update.message.reply_text(M()['ask_amount_syp'], parse_mode='Markdown')
        return
    if step == WAITING_AMOUNT:
        try:
            amount = float(text)
            rtype = context.user_data.get('recharge_type')

            # لسيرياتيل: transfer_id مطلوب (تم أخذه سابقًا)، لا صورة
            if rtype == "سيرياتيل كاش":
                await send_recharge_request_to_admin(
                    update, context, amount, rtype,
                    transfer_id=context.user_data.pop('temp_transfer', None),
                    photo_file_id=None
                )
            else:
                # باقي الطرق: صورة مطلوبة (أخذناها في handle_photo)
                await send_recharge_request_to_admin(
                    update, context, amount, rtype,
                    transfer_id=None,
                    photo_file_id=context.user_data.pop('temp_photo', None)
                )

            # تنظيف
            for k in ['recharge_step', 'recharge_type', 'temp_transfer', 'temp_photo']:
                context.user_data.pop(k, None)

        except ValueError:
            await update.message.reply_text("❌ المبلغ غير صالح. أرسل رقمًا صحيحًا أو عشريًا.")
        return

    # أزرار عامة
    if text == "رجوع":
        if user_id == ADMIN_ID:
            await admin_panel(update, context)
        else:
            await show_main_menu(update, context)
        return

    # أوامر المدير
    if user_id == ADMIN_ID:
        if text == "📊 الإحصائيات":
            await show_admin_stats(update, context)
        elif text == "⚙️ تعديل سعر الرقم":
            await update.message.reply_text(M()['edit_price'].format(get_phone_price()), parse_mode='Markdown')
            context.user_data['editing'] = 'price'
        elif text == "📝 تعديل عناوين الشحن":
            await update.message.reply_text(M()['edit_addresses_prompt'], reply_markup=k_b(kb_charge), parse_mode='Markdown')
            context.user_data['address_select'] = True
        elif text == "📋 طلبات الشحن":
            await manage_requests(update, context)
        elif text == "➕ إضافة رصيد يدوي":
            context.user_data['editing'] = 'add_balance'
            await update.message.reply_text("أرسل: ID المبلغ  (مثال: 123 50)")
        elif text == "➖ خصم رصيد يدوي":
            context.user_data['editing'] = 'deduct_balance'
            await update.message.reply_text("أرسل: ID المبلغ  (مثال: 123 5)")
        elif text == "💵 سعر الدولار":
            context.user_data['editing'] = 'usd_rate'
            await update.message.reply_text(M()['usd_rate_prompt'], parse_mode='Markdown')
        elif context.user_data.get('address_select') and text in ["شام كاش (ل.س)", "شام كاش (دولار)", "USDT (BEP20)", "سيرياتيل كاش"]:
            key_map = {
                "شام كاش (ل.س)": 'sham_cash_sp',
                "شام كاش (دولار)": 'sham_cash_usd',
                "USDT (BEP20)": 'usdt_bep20',
                "سيرياتيل كاش": 'syriatel_cash'
            }
            edit_key = key_map.get(text)
            if edit_key:
                context.user_data['editing'] = 'address'
                context.user_data['edit_key'] = edit_key
                context.user_data['edit_method'] = text
                await update.message.reply_text(f"✏️ أرسل **العنوان الجديد** لـ **{text}**:", parse_mode='Markdown')
            context.user_data.pop('address_select', None)
        elif text == "عرض جميع المستخدمين":
            try:
                users = supabase.table('users').select('user_id, username, balance').execute()
                s = "👥 **المستخدمون:**\n\n"
                for u in users.data[:50]:
                    s += f"• @{u.get('username','-')} (ID: {u['user_id']}) — رصيد: {u.get('balance',0)}\n"
                await update.message.reply_text(s, parse_mode='Markdown')
            except Exception:
                await update.message.reply_text(M()['error'].format("عرض المستخدمين"))
        else:
            await update.message.reply_text(M()['use_buttons'])
        return

    # أوامر المستخدم
    if text == "👤 حسابي":
        bal = await get_user_balance(user_id)
        await update.message.reply_text(M()['account'].format(user_id, bal), parse_mode='Markdown')
    elif text == "🔑 شراء رقم مؤقت":
        await update.message.reply_text(M()['choose_country'], reply_markup=k_b(kb_countries), parse_mode='Markdown')
        context.user_data['waiting_country'] = True
    elif text == "💳 شحن الحساب":
        await update.message.reply_text(M()['choose_method'], reply_markup=k_b(kb_charge), parse_mode='Markdown')
    elif text == "✉️ الحصول على الكود":
        await get_sms_code(update, context)
    elif text in ["شام كاش (ل.س)", "شام كاش (دولار)", "USDT (BEP20)"]:
        await start_recharge_flow(update, context, text)
    elif text == "سيرياتيل كاش":
        await start_recharge_flow(update, context, text, is_syriatel=True)
    else:
        await update.message.reply_text(M()['use_buttons'])

# =========================
# 14) Error Handler
# =========================
async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.warning('Update "%s" caused error "%s"', update, context.error)

# =========================
# 15) Main (Webhook on Render)
# =========================
def main():
    if not BOT_TOKEN or not os.getenv('RENDER_EXTERNAL_HOSTNAME'):
        logger.error("Missing BOT_TOKEN or RENDER_EXTERNAL_HOSTNAME.")
        return

    app = Application.builder().token(BOT_TOKEN).build()

    # محادثة التسجيل
    reg_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={
            USERNAME_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, username_handler)],
            PASSWORD_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, password_handler)],
            CAPTCHA_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, captcha_check)],
        },
        fallbacks=[CommandHandler('cancel', cancel)],
    )
    app.add_handler(reg_handler)

    # أوامر
    app.add_handler(CommandHandler("admin", admin_panel))

    # كولباكات
    app.add_handler(CallbackQueryHandler(admin_approval_callback, pattern=r"^req_(approve|reject)_"))
    app.add_handler(CallbackQueryHandler(phone_inline_callback, pattern=r"^(blacklist_|repurchase_)"))

    # صور
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))

    # نصوص عامة
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, button_handler))

    # أخطاء
    app.add_error_handler(error_handler)

    # Webhook
    PORT = int(os.getenv('PORT', 10000))
    HOSTNAME = os.getenv('RENDER_EXTERNAL_HOSTNAME')
    WEBHOOK_URL = f"https://{HOSTNAME}/{BOT_TOKEN}"

    logger.info(f"Starting webhook at {WEBHOOK_URL}")
    app.run_webhook(
        listen="0.0.0.0",
        port=PORT,
        url_path=BOT_TOKEN,
        webhook_url=WEBHOOK_URL,
    )

if __name__ == "__main__":
    main()
