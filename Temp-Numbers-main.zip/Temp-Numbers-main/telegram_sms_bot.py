import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes, ConversationHandler
import requests
import time
import os
from dotenv import load_dotenv
from supabase import create_client, Client
import bcrypt
from io import BytesIO

# Load env vars
load_dotenv()

USERNAME = os.getenv('USERNAME')
API_KEY = os.getenv('API_KEY')
PID = int(os.getenv('PID', 0))
BOT_TOKEN = os.getenv('BOT_TOKEN')
COUNTRY = os.getenv('COUNTRY', 'bo')
NUM_COUNT = int(os.getenv('NUM_COUNT', 1))
SERIAL = int(os.getenv('SERIAL', 2))
ADMIN_ID = int(os.getenv('ADMIN_ID', 0))

SUPABASE_URL = os.getenv('SUPABASE_URL')
SUPABASE_KEY = os.getenv('SUPABASE_KEY')
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

if not all([BOT_TOKEN, USERNAME, API_KEY, PID]):
    raise ValueError("خطأ في env vars!")

BASE_URL = "https://api.durianrcs.com/out/ext_api"

logging.basicConfig(level=logging.INFO)

# States
LANGUAGE_STATE, USERNAME_STATE, PASSWORD_STATE, CAPTCHA_STATE = range(4)

def get_messages(language):
    if language == 'ar':
        return {
            'choose_language': 'اختر اللغة:',
            'welcome': 'مرحباً! أنشئ حسابك:',
            'ask_username': 'أرسل يوزرنيم:',
            'username_saved': 'يوزرنيم محفوظ. دلوقتي الباسوورد:',
            'password_saved': 'باسوورد محفوظ. CAPTCHA: 22-21=؟',
            'captcha_success': 'ممتاز! تسجيل ناجح. مرحباً!',
            'choose_action': 'اختار عملية:',
            'low_balance': 'رصيد ناقص! شحن أول.',
            'deducted': 'تم خصم {} credits. رصيد جديد: {}.',
            'balance': 'رصيدك: {} credits',
            'choose_method': 'اختار طريقة الشحن:',
            'ask_amount': 'أرسل المبلغ للشحن:',
            'request_sent': 'تم إرسال طلب الشحن للأدمن. انتظر الموافقة.',
            'photo_sent': 'تم إرسال الصورة. رصيدك حدّث.',
            'wrong_captcha': 'خطأ! جرب تاني: 22-21=؟',
            'too_many_attempts': 'لم نستطع التأكد، أعد المحاولة لاحقاً.',
            'username_taken': 'يوزرنيم موجود، جرب غيره.',
            'use_buttons': 'استخدم الأزرار.',
            'phone_received': 'الرقم: {}',
            'error': 'خطأ: {}',
            'admin_welcome': 'مرحباً أدمن! لوحة التحكم:',
            'admin_stats': 'عدد المستخدمين: {}',
            'edit_addresses': 'عدّل عناوين الشحن:',
            'edit_price': 'عدّل سعر الرقم (حالي {}): أرسل الرقم الجديد',
            'price_updated': 'سعر الرقم حدّث ل: {}',
            'address_updated': 'عنوان {} حدّث ل: {}',
            'requests_list': 'طلبات الشحن:\n{}',
            'approve': 'موافقة',
            'reject': 'رفض',
            'approval_notification': 'تم الموافقة على طلبك! رصيدك حدّث.',
            'rejection_notification': 'تم رفض طلبك. اتصل بالدعم.',
            'no_phone': 'اشترِ رقم أول.',
            'no_sms': 'مش لاقي SMS. أضفت للـ blacklist.',
            'searching': 'جاري البحث عن الكود...',
            'choose_language': 'اختر اللغة:',
            'language_ar': 'العربية',
            'language_en': 'English'
        }
    else:
        return {
            'choose_language': 'Choose language:',
            'welcome': 'Hi! Create account:',
            'ask_username': 'Send username:',
            'username_saved': 'Username saved. Now password:',
            'password_saved': 'Password saved. CAPTCHA: 22-21=?',
            'captcha_success': 'Great! Registration successful. Welcome!',
            'choose_action': 'Choose action:',
            'low_balance': 'Low balance! Recharge first.',
            'deducted': 'Deducted {} credits. New balance: {}.',
            'balance': 'Your balance: {} credits',
            'choose_method': 'Choose recharge method:',
            'ask_amount': 'Send the amount for recharge:',
            'request_sent': 'Recharge request sent to admin. Wait for approval.',
            'photo_sent': 'Photo sent. Balance updated.',
            'wrong_captcha': 'Wrong! Try again: 22-21=?',
            'too_many_attempts': 'Could not verify, try later.',
            'username_taken': 'Username taken, try another.',
            'use_buttons': 'Use buttons.',
            'phone_received': 'Phone: {}',
            'error': 'Error: {}',
            'admin_welcome': 'Welcome Admin! Control panel:',
            'admin_stats': 'Users count: {}',
            'edit_addresses': 'Edit recharge addresses:',
            'edit_price': 'Edit phone price (current {}): Send new value',
            'price_updated': 'Phone price updated to: {}',
            'address_updated': 'Address {} updated to: {}',
            'requests_list': 'Recharge requests:\n{}',
            'approve': 'Approve',
            'reject': 'Reject',
            'approval_notification': 'Your recharge request approved! Balance updated.',
            'rejection_notification': 'Your recharge request rejected. Contact support.',
            'no_phone': 'Buy a phone first.',
            'no_sms': 'No SMS. Added to blacklist.',
            'searching': 'Searching for code...',
            'choose_language': 'Choose language:',
            'language_ar': 'Arabic',
            'language_en': 'English'
        }

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    language = context.user_data.get('language', 'ar')
    text = get_messages(language)['choose_action']
    keyboard = get_main_keyboard(language)
    await update.message.reply_text(text, reply_markup=keyboard)

def get_main_keyboard(language):
    if language == 'ar':
        keyboard = [
            [KeyboardButton("شراء رقم مؤقت")],
            [KeyboardButton("رصيدي")],
            [KeyboardButton("شحن الحساب")],
            [KeyboardButton("الحصول على الكود")]
        ]
    else:
        keyboard = [
            [KeyboardButton("Buy a Temp Number")],
            [KeyboardButton("My Balance")],
            [KeyboardButton("Charge My Account")],
            [KeyboardButton("Get Code")]
        ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def get_charge_keyboard(language):
    if language == 'ar':
        keyboard = [
            [KeyboardButton("شام كاش (S.P)")],
            [KeyboardButton("شام كاش (USD)")],
            [KeyboardButton("USDT (BEP20)")],
            [KeyboardButton("سيرياتل كاش")],
            [KeyboardButton("رجوع")]
        ]
    else:
        keyboard = [
            [KeyboardButton("Sham Cash (S.P)")],
            [KeyboardButton("Sham Cash (USD)")],
            [KeyboardButton("USDT (BEP20)")],
            [KeyboardButton("Syriatel Cash")],
            [KeyboardButton("Back")]
        ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

def get_admin_keyboard(language):
    if language == 'ar':
        keyboard = [
            [KeyboardButton("إحصائيات")],
            [KeyboardButton("تعديل عناوين الشحن")],
            [KeyboardButton("تعديل سعر الرقم")],
            [KeyboardButton("طلبات الشحن")],
            [KeyboardButton("رجوع")]
        ]
    else:
        keyboard = [
            [KeyboardButton("Stats")],
            [KeyboardButton("Edit Recharge Addresses")],
            [KeyboardButton("Edit Phone Price")],
            [KeyboardButton("Recharge Requests")],
            [KeyboardButton("Back")]
        ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    language = context.user_data.get('language', 'ar')
    help_text = get_messages(language)['help']
    keyboard = get_main_keyboard(language)
    await update.message.reply_text(help_text, reply_markup=keyboard)

async def username_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    language = context.user_data.get('language', 'ar')
    username = update.message.text.strip()
    user_id = update.effective_user.id
    try:
        data = supabase.table('users').select('*').eq('username', username).execute()
        if len(data.data) > 0:
            await update.message.reply_text(get_messages(language)['username_taken'])
            return USERNAME_STATE
        context.user_data['temp_username'] = username
        logging.info(f"Temp username saved for user {user_id}: {username}")
    except Exception as e:
        logging.error(f"DB username check error: {e}")
        await update.message.reply_text("خطأ في التحقق، جرب تاني.")
        return USERNAME_STATE
    await update.message.reply_text(get_messages(language)['username_saved'])
    return PASSWORD_STATE

async def password_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    language = context.user_data.get('language', 'ar')
    password = update.message.text.strip()
    user_id = update.effective_user.id
    username = context.user_data.get('temp_username')
    if not username:
        await update.message.reply_text("خطأ، ابدأ من جديد ب /start.")
        return PASSWORD_STATE
    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt()).decode('utf-8')
    try:
        supabase.table('users').insert({
            'user_id': user_id,
            'username': username,
            'password': hashed,
            'balance': 0.00,
            'attempts': 0,
            'language': language
        }).execute()
        logging.info(f"User {user_id} registered with username {username}")
        del context.user_data['temp_username']
    except Exception as e:
        logging.error(f"DB insert error: {e}")
        await update.message.reply_text("خطأ في حفظ التسجيل، جرب تاني.")
        return PASSWORD_STATE
    await update.message.reply_text(get_messages(language)['password_saved'])
    return CAPTCHA_STATE

async def captcha_check(update: Update, context: ContextTypes.DEFAULT_TYPE):
    language = context.user_data.get('language', 'ar')
    answer = update.message.text.strip()
    user_id = update.effective_user.id
    if answer == "1":
        try:
            supabase.table('users').update({'attempts': 0}).eq('user_id', user_id).execute()
            logging.info(f"CAPTCHA success for user {user_id}")
        except Exception as e:
            logging.error(f"DB CAPTCHA error: {e}")
        await update.message.reply_text(get_messages(language)['captcha_success'])
        await show_main_menu(update, context)
        return ConversationHandler.END
    else:
        try:
            data = supabase.table('users').select('attempts').eq('user_id', user_id).execute()
            attempts = (data.data[0]['attempts'] + 1) if data.data else 1
            supabase.table('users').update({'attempts': attempts, 'last_attempt': time.time()}).eq('user_id', user_id).execute()
        except Exception as e:
            logging.error(f"DB CAPTCHA update error: {e}")
        if attempts >= 3:
            await update.message.reply_text(get_messages(language)['too_many_attempts'])
            return ConversationHandler.END
        else:
            await update.message.reply_text(get_messages(language)['wrong_captcha'])
            return CAPTCHA_STATE

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("تم إلغاء التسجيل.")
    return ConversationHandler.END

# /admin command
async def admin_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        await update.message.reply_text("غير مصرّح لك.")
        return
    language = context.user_data.get('language', 'ar')
    text = get_messages(language)['admin_welcome']
    keyboard = get_admin_keyboard(language)
    await update.message.reply_text(text, reply_markup=keyboard)

# Handler for buttons
async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    language = context.user_data.get('language', 'ar')
    text = update.message.text.strip()
    user_id = update.effective_user.id
    
    # Ignore commands
    if text.startswith('/'):
        return
    
    if text == ("Buy a Temp Number" if language == 'en' else "شراء رقم مؤقت"):
        balance = await get_user_balance(user_id)
        price = get_phone_price()
        if balance < price:
            await update.message.reply_text(get_messages(language)['low_balance'])
            return
        await get_phone(update, context)
        new_balance = balance - price
        supabase.table('users').update({'balance': new_balance}).eq('user_id', user_id).execute()
        await update.message.reply_text(get_messages(language)['deducted'].format(price, new_balance))
    
    elif text == ("My Balance" if language == 'en' else "رصيدي"):
        balance = await get_user_balance(user_id)
        msg = get_messages(language)['balance'].format(balance)
        await update.message.reply_text(msg)
    
    elif text == ("Charge My Account" if language == 'en' else "شحن الحساب"):
        text = get_messages(language)['choose_method']
        keyboard = get_charge_keyboard(language)
        await update.message.reply_text(text, reply_markup=keyboard)
    
    elif text == ("Get Code" if language == 'en' else "الحصول على الكود"):
        await get_code(update, context)
    
    elif text in [("Sham Cash (S.P)" if language == 'en' else "شام كاش (S.P)"), ("Sham Cash (USD)" if language == 'en' else "شام كاش (USD)"), ("USDT (BEP20)" if language == 'en' else "USDT (BEP20)"), ("Syriatel Cash" if language == 'en' else "سيرياتل كاش")]:
        address = get_recharge_address(text)
        msg = get_recharge_message(language, text, address)
        await update.message.reply_text(msg)
        context.user_data['payment_type'] = text
        await update.message.reply_text(get_messages(language)['ask_amount'])
    
    elif text == ("Back" if language == 'en' else "رجوع"):
        await show_main_menu(update, context)
    
    elif user_id == ADMIN_ID:
        if text == ("Statistics" if language == 'en' else "إحصائيات"):
            users_count = len(supabase.table('users').select('*').execute().data)
            msg = get_messages(language)['admin_stats'].format(users_count)
            await update.message.reply_text(msg)
        elif text == ("Edit Recharge Addresses" if language == 'en' else "تعديل عناوين الشحن"):
            text = get_messages(language)['edit_addresses']
            keyboard = get_addresses_keyboard(language)
            await update.message.reply_text(text, reply_markup=keyboard)
        elif text == ("Edit Phone Price" if language == 'en' else "تعديل سعر الرقم"):
            current_price = get_phone_price()
            text = get_messages(language)['edit_price'].format(current_price)
            await update.message.reply_text(text)
            context.user_data['editing'] = 'price'
        elif text == ("Recharge Requests" if language == 'en' else "طلبات الشحن"):
            requests = get_pending_requests()
            text = get_messages(language)['requests_list'].format(format_requests(requests, language))
            keyboard = get_requests_keyboard(requests)
            await update.message.reply_text(text, reply_markup=keyboard)
        else:
            await update.message.reply_text("استخدم الأزرار.")
    else:
        await update.message.reply_text(get_messages(language)['use_buttons'])

async def get_recharge_message(language, method, address):
    if language == 'ar':
        return f"🔵 قم بإرسال رصيد {method} إلى الحساب التالي:\n     {address}\n\n🔵 يتم معالجة الطلب خلال 60 دقيقة\n🔻 أرسل صورة لعملية التحويل"
    else:
        return f"🔵 Send {method} balance to the following account:\n     {address}\n\n🔵 The request will be processed within 60 minutes\n🔻 Send a screenshot of the transfer"

def get_phone_price():
    try:
        data = supabase.table('settings').select('value').eq('key', 'phone_price').execute()
        return float(data.data[0]['value']) if data.data else 5
    except:
        return 5

def get_recharge_address(method):
    key = method.lower().replace(' ', '_').replace('(s.p)', 'sp').replace('(usd)', 'usd').replace('(bep20)', 'bep20')
    try:
        data = supabase.table('settings').select('value').eq('key', key).execute()
        return data.data[0]['value'] if data.data else 'default_address'
    except:
        return 'default_address'

def get_pending_requests():
    try:
        data = supabase.table('recharge_requests').select('*').eq('status', 'pending').execute()
        return data.data
    except:
        return []

def format_requests(requests, language):
    if not requests:
        return "لا توجد طلبات شحن معلقة." if language == 'ar' else "No pending requests."
    formatted = ""
    for req in requests:
        if language == 'ar':
            formatted += f"طلب ID: {req['id']}, المستخدم: {req['user_id']}, الطريقة: {req['payment_type']}, المبلغ: {req['amount']}\n"
        else:
            formatted += f"Request ID: {req['id']}, User: {req['user_id']}, Type: {req['payment_type']}, Amount: {req['amount']}\n"
    return formatted

def get_requests_keyboard(requests):
    keyboard = []
    for req in requests:
        row = [
            KeyboardButton(f"موافقة {req['amount']} لـ {req['user_id']}"),
            KeyboardButton(f"رفض {req['user_id']}")
        ]
        keyboard.append(row)
    keyboard.append([KeyboardButton("رجوع")])
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=True)

async def admin_approve_reject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    if "موافقة" in text or "Approve" in text:
        parts = text.split()
        amount = float(parts[1])
        user_id = int(parts[3])
        supabase.table('users').update({'balance': await get_user_balance(user_id) + amount}).eq('user_id', user_id).execute()
        req_id = int(parts[-1])
        supabase.table('recharge_requests').update({'status': 'approved'}).eq('id', req_id).execute()
        await context.bot.send_message(user_id, "تم الموافقة على طلبك! رصيدك حدّث.")
        await update.message.reply_text("تم الموافقة.")
    elif "رفض" in text or "Reject" in text:
        user_id = int(text.split()[1])
        req_id = int(text.split()[-1])
        supabase.table('recharge_requests').update({'status': 'rejected'}).eq('id', req_id).execute()
        await context.bot.send_message(user_id, "تم رفض طلبك. اتصل بالدعم.")
        await update.message.reply_text("تم الرفض.")

async def language_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    if text == "العربية":
        context.user_data['language'] = 'ar'
    elif text == "English":
        context.user_data['language'] = 'en'
    else:
        await update.message.reply_text("اختر اللغة صحيحة.")
        return LANGUAGE_STATE
    await start(update, context)
    return LANGUAGE_STATE

conv_handler = ConversationHandler(
    entry_points=[CommandHandler('start', start)],
    states={
        LANGUAGE_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, language_handler)],
        USERNAME_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, username_handler)],
        PASSWORD_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, password_handler)],
        CAPTCHA_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, captcha_check)],
    },
    fallbacks=[CommandHandler('cancel', cancel)],
)

def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(conv_handler)
    app.add_handler(CommandHandler("help", help_command))
    app.add_handler(CommandHandler("admin", admin_command))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, button_handler))
    
    # Webhook
    PORT = int(os.getenv('PORT', 10000))
    HOSTNAME = os.getenv('RENDER_EXTERNAL_HOSTNAME')
    if not HOSTNAME:
        raise ValueError("أضف RENDER_EXTERNAL_HOSTNAME!")
    WEBHOOK_URL = f"https://{HOSTNAME}/{BOT_TOKEN}"
    
    app.bot.set_webhook(url=WEBHOOK_URL)
    logging.info(f"Webhook set to {WEBHOOK_URL}")
    
    app.run_webhook(
        listen="0.0.0.0",
        port=PORT,
        url_path=BOT_TOKEN,
        webhook_url=WEBHOOK_URL
    )

if __name__ == "__main__":
    main()