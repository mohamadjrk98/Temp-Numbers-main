import logging
import time
import os
from dotenv import load_dotenv
import requests
import bcrypt
from io import BytesIO

# استيرادات Telegram و Extensions
from telegram import Update, ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import (
    Application, CommandHandler, MessageHandler, filters, ContextTypes, 
    ConversationHandler, CallbackQueryHandler
)

from supabase import create_client, Client

# 1. الإعدادات وتحميل المتغيرات

load_dotenv()

USERNAME = os.getenv('USERNAME')
API_KEY = os.getenv('API_KEY')
PIDS = [pid.strip() for pid in os.getenv('PID', '').split(',') if pid.strip()]
BOT_TOKEN = os.getenv('BOT_TOKEN')
COUNTRY = os.getenv('COUNTRY', 'us')
NUM_COUNT = int(os.getenv('NUM_COUNT', 1))
SERIAL = int(os.getenv('SERIAL', 2))
ADMIN_ID = int(os.getenv('ADMIN_ID', 0))

SUPABASE_URL = os.getenv('SUPABASE_URL')
SUPABASE_KEY = os.getenv('SUPABASE_KEY')

try:
    supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
except Exception as e:
    logging.error(f"Failed to create Supabase client: {e}")
    raise

if not all([BOT_TOKEN, USERNAME, API_KEY, SUPABASE_URL, SUPABASE_KEY, ADMIN_ID]) or not PIDS:
    raise ValueError("Missing required environment variables or PIDS list is empty!")

BASE_URL = "https://api.durianrcs.com/out/ext_api"

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

USERNAME_STATE, PASSWORD_STATE, CAPTCHA_STATE = range(3)
WAITING_TRANSFER_ID = 11
WAITING_PHOTO = 12
WAITING_AMOUNT = 13
WAITING_COUNTRY = 20
WAITING_SERVICE = 21

# 2. رسائل البوت

def get_messages():
    return {
        'welcome': 'مرحباً! قم بإنشاء حسابك:',
        'ask_username': 'أرسل اسم المستخدم:',
        'username_saved': 'تم حفظ اسم المستخدم. الآن أرسل كلمة المرور:',
        'password_saved': 'تم حفظ كلمة المرور. قم بحل الكابتشا: 22-21=?',
        'captcha_success': 'عظيم! تم التسجيل بنجاح. أهلاً بك!',
        'choose_action': 'اختر إجراءً:',
        'low_balance': 'الرصيد منخفض! يرجى الشحن أولاً.',
        'deducted': 'تم خصم {} رصيد. الرصيد الجديد: {}.',
        'balance': 'رصيدك الحالي: {} رصيد',
        'choose_method': 'اختر طريقة الشحن:',
        'ask_amount': 'يرجى إرسال **المبلغ** الذي قمت بشحنه (رقم صحيح أو عشري):',
        'request_sent': '✅ تم إرسال طلب الشحن للمدير للمراجعة (ID: {}). سيتم إشعارك فور الموافقة.',
        'photo_sent': 'تم استلام الإثبات بنجاح.',
        'wrong_captcha': 'خطأ! حاول مرة أخرى: 22-21=?',
        'too_many_attempts': 'لم نتمكن من التحقق. حاول مرة أخرى لاحقاً.',
        'username_taken': 'اسم المستخدم محجوز بالفعل. جرب اسماً آخر.',
        'use_buttons': 'الرجاء استخدام الأزرار.',
        'phone_received': 'تم شراء رقم مؤقت: {}',
        'error': 'حدث خطأ: {}',
        'admin_welcome': '🎛️ **لوحة التحكم الرئيسية** 🎛️\n\nمرحباً أيها المدير! اختر إجراءً من القائمة أدناه:',
        'admin_stats': '📈 **الإحصائيات العامة**:\n\n• إجمالي المستخدمين: {}\n• إجمالي طلبات الشحن اليوم: {}',
        'edit_addresses_prompt': '📝 **تعديل عناوين الشحن**:\n\nاختر الطريقة لتعديل عنوانها:',
        'edit_price': '⚙️ **تعديل سعر الرقم** (الحالي: {}):\n\nأرسل القيمة الجديدة (رقم عشري):',
        'price_updated': '✅ تم تحديث سعر الرقم إلى: {}',
        'address_updated': '✅ تم تحديث عنوان **{}** إلى: {}',
        'approval_notification': '✅ تم قبول طلب الشحن الخاص بك! تم إضافة {} رصيد إلى حسابك. رصيدك الجديد: {}.',
        'rejection_notification': '❌ تم رفض طلب الشحن الخاص بك. تواصل مع الدعم للمساعدة.',
        'no_phone': 'يرجى شراء رقم مؤقت أولاً.',
        'no_sms': 'لم يتم العثور على رسالة. تم إضافة الرقم للقائمة السوداء.',
        'searching': '🔎 جارٍ البحث عن الكود... قد يستغرق الأمر دقيقة.',
        'access_denied': '❌ الوصول مرفوض.',
        'syriatel_cash_prompt': '📞 **الشحن عبر سيرياتيل كاش**:\n\nيرجى إرسال **رقم عملية التحويل** (Transfer Operation Number) الآن. بعدها سنطلب منك صورة الإثبات والمبلغ.',
        'transfer_id_saved': '✅ تم حفظ رقم العملية. الآن، يرجى إرسال **صورة إثبات التحويل**.',
        'buy_phone_prompt': 'جاري شراء رقم مؤقت...',
        'get_code_prompt': 'جاري البحث عن الكود...',
        'requests_list': '📋 **طلبات الشحن قيد الانتظار**:\n\n(سيتم عرض القائمة هنا)',
        'services_manage': '🛠️ **إدارة الخدمات**:\n\nاختر خدمة للإدارة:',
        'choose_country': '🌍 **اختر الدولة لشراء الرقم المؤقت**:\n\n(يمكنك إضافة المزيد لاحقاً):',
        'country_selected': '✅ تم اختيار الدولة: {}. الآن اختر الخدمة:',
        'choose_service': '📱 **اختر الخدمة المطلوبة للرقم**:\n\n(الخدمات المتاحة):',
        'service_selected': '✅ تم اختيار الخدمة: {}. جاري شراء الرقم...',
        'next_page': 'التالي ➡️',
        'prev_page': '⬅️ السابق',
        'service_page_info': 'صفحة {} من {}',
    }

# 3. لوحات المفاتيح

def get_main_keyboard():
    keyboard = [
        [KeyboardButton("🔑 شراء رقم مؤقت")],
        [KeyboardButton("💰 رصيدي"), KeyboardButton("💳 شحن الحساب")],
        [KeyboardButton("✉️ الحصول على الكود")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_countries_keyboard():
    keyboard = [
        [KeyboardButton("🇺🇸 USA")],
        [KeyboardButton("رجوع")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_services_keyboard(context: ContextTypes.DEFAULT_TYPE):
    services = list(SERVICE_TO_PID.keys())
    page = context.user_data.get('service_page', 0)
    items_per_page = 6
    
    if len(services) <= items_per_page:
        keyboard = [[KeyboardButton(service)] for service in services]
        keyboard.append([KeyboardButton("رجوع")])
    else:
        start_idx = page * items_per_page
        end_idx = min(start_idx + items_per_page, len(services))
        page_services = services[start_idx:end_idx]
        
        keyboard = [[KeyboardButton(service)] for service in page_services]
        nav_row = []
        if page > 0:
            nav_row.append(KeyboardButton(get_messages()['prev_page']))
        if end_idx < len(services):
            nav_row.append(KeyboardButton(get_messages()['next_page']))
        if nav_row:
            keyboard.append(nav_row)
        page_info = get_messages()['service_page_info'].format(page + 1, (len(services) + items_per_page - 1) // items_per_page)
        keyboard.append([KeyboardButton("رجوع")])
    
    markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    return markup, page_info if 'page_info' in locals() else None

def get_charge_keyboard():
    keyboard = [
        [KeyboardButton("شام كاش (ل.س)"), KeyboardButton("شام كاش (دولار)")],
        [KeyboardButton("USDT (BEP20)"), KeyboardButton("سيرياتيل كاش")],
        [KeyboardButton("رجوع")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_admin_keyboard():
    keyboard = [
        [KeyboardButton("📊 الإحصائيات"), KeyboardButton("⚙️ تعديل سعر الرقم")],
        [KeyboardButton("📝 تعديل عناوين الشحن"), KeyboardButton("📋 طلبات الشحن")],
        [KeyboardButton("🛠️ إدارة الخدمات"), KeyboardButton("🔒 إدارة المستخدمين")],
        [KeyboardButton("📤 تصدير البيانات"), KeyboardButton("رجوع")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_admin_services_keyboard():
    """Keyboard for managing services."""
    keyboard = [
        [KeyboardButton("تفعيل/تعطيل الخدمة"), KeyboardButton("تعديل الإعدادات")],
        ["رجوع"]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

def get_users_management_keyboard():
    keyboard = [
        [KeyboardButton("حظر مستخدم"), KeyboardButton("إضافة رصيد يدوي")],
        [KeyboardButton("عرض جميع المستخدمين"), KeyboardButton("رجوع")]
    ]
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

# باقي الكود كما هو بدون أي تغيير (كل الدوال الأخرى تعمل كما كانت)
# فقط تم تعديل اسم الدالة الثانية "get_services_keyboard" إلى "get_admin_services_keyboard"
# واستدعاؤها في:
# await update.message.reply_text(get_messages()['services_manage'], reply_markup=get_admin_services_keyboard(), parse_mode='Markdown')

SERVICE_TO_PID = {
    "📧 Gmail 1": "0097",
    "📧 Gmail 2": "0098",
    "🪟 Microsoft": "0241",
    "💰 Swagbucks": "0652",
    "💌 InboxDollars": "1072",
    "📊 Ipsos": "2397",
    "🟢 ATTAPOL": "1998"  # ✅ الخدمة الجديدة
}

# 4. دوال Supabase والمساعدات الأساسية

def is_registered(user_id: int) -> bool:
    """Check if user is registered in DB."""
    try:
        data = supabase.table('users').select('user_id').eq('user_id', user_id).execute()
        return len(data.data) > 0
    except Exception as e:
        logger.error(f"DB registration check error: {e}")
        return False

async def get_user_balance(user_id: int) -> float:
    """Fetch user balance from DB."""
    try:
        data = supabase.table('users').select('balance').eq('user_id', user_id).execute()
        return float(data.data[0]['balance']) if data.data else 0.0
    except Exception as e:
        logger.error(f"DB balance fetch error: {e}")
        return 0.0

async def update_user_balance(user_id: int, new_balance: float):
    """Update user balance in DB."""
    try:
        supabase.table('users').update({'balance': new_balance}).eq('user_id', user_id).execute()
    except Exception as e:
        logger.error(f"DB balance update error: {e}")

def get_phone_price() -> float:
    """Fetch phone price from DB."""
    try:
        data = supabase.table('settings').select('value').eq('key', 'phone_price').execute()
        return float(data.data[0]['value']) if data.data else 5.0
    except Exception as e:
        logger.error(f"DB price fetch error: {e}")
        return 5.0

def get_recharge_address(method: str) -> str:
    """Fetch recharge address for method from DB."""
    key = method.lower().replace(' ', '_').replace('(ل.س)', 'sp').replace('(دولار)', 'usd').replace('(bep20)', 'bep20')
    try:
        data = supabase.table('settings').select('value').eq('key', key).execute()
        return data.data[0]['value'] if data.data else 'غير محدد'
    except Exception as e:
        logger.error(f"DB address fetch error: {e}")
        return 'غير محدد'

def get_recharge_message(method: str, address: str) -> str:
    """Generate recharge message."""
    return f"🏦 طريقة الشحن: **{method}**\n\nأرسل المبلغ إلى:\n`{address}`\n\nالرجاء **إرسال صورة إثبات التحويل** الآن. بعدها سنطلب منك المبلغ."

def get_next_recharge_id() -> int:
    """Generate next recharge request ID."""
    try:
        data = supabase.table('settings').select('value').eq('key', 'recharge_id_sequence').execute()
        if data.data:
            last_id = int(data.data[0]['value'])
            next_id = last_id + 1
            supabase.table('settings').update({'value': str(next_id)}).eq('key', 'recharge_id_sequence').execute()
            return next_id
        else:
            initial_id = 2300
            supabase.table('settings').insert({'key': 'recharge_id_sequence', 'value': str(initial_id + 1)}).execute()
            return initial_id
    except Exception as e:
        logger.error(f"Error getting/updating recharge ID sequence: {e}")
        return 990000 + int(time.time())

async def send_recharge_request_to_admin(update: Update, context: ContextTypes.DEFAULT_TYPE, amount: float, recharge_type: str, transfer_id: str = None, photo_file_id: str = None):
    """Send recharge request to admin."""
    request_id = get_next_recharge_id()
    user = update.effective_user
    
    try:
        supabase.table('recharge_requests').insert({
            'id': request_id,
            'user_id': user.id,
            'username': user.username or str(user.id),
            'payment_type': recharge_type,
            'amount': amount,
            'status': 'pending',
            'photo_file_id': photo_file_id,
            'transfer_id': transfer_id
        }).execute()
    except Exception as e:
        logger.error(f"DB insert recharge request error: {e}")
        await update.message.reply_text(get_messages()['error'].format("حفظ الطلب في قاعدة البيانات."))
        return

    source_info = f"رقم عملية التحويل: `{transfer_id}`" if transfer_id else "تم إرسال الإثبات كصورة مُرفقة."
    
    admin_message = (
        f"🚨 **طلب شحن جديد (ID: {request_id})** 🚨\n\n"
        f"• المستخدم: @{user.username or user.id} (ID: `{user.id}`)\n"
        f"• طريقة الشحن: **{recharge_type}**\n"
        f"• المبلغ المطلوب: **{amount}**\n"
        f"• تفاصيل الإثبات: {source_info}\n\n"
        "الرجاء مراجعة الإثبات واتخاذ الإجراء."
    )
    
    keyboard = InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ موافقة", callback_data=f"req_approve_{request_id}"),
            InlineKeyboardButton("❌ رفض", callback_data=f"req_reject_{request_id}")
        ]
    ])
    
    try:
        if photo_file_id:
            await context.bot.send_photo(
                ADMIN_ID, 
                photo_file_id, 
                caption=admin_message, 
                reply_markup=keyboard,
                parse_mode='Markdown'
            )
        else:
            await context.bot.send_message(
                ADMIN_ID, 
                admin_message, 
                reply_markup=keyboard,
                parse_mode='Markdown'
            )
        
        await update.message.reply_text(get_messages()['request_sent'].format(request_id))
    except Exception as e:
        logger.error(f"Error sending recharge request to admin: {e}")
        await update.message.reply_text(get_messages()['error'].format("تعذر إرسال الطلب للمدير. الرجاء المحاولة لاحقاً."))

# 5. دوال التعامل مع API الخارجي (شراء رقم واستلام SMS)

async def buy_temp_phone(update: Update, context: ContextTypes.DEFAULT_TYPE, country_code: str, service_pid: str):
    """شراء رقم مؤقت من DurianRCS API (نسخة محدثة ومتوافقة مع الإصدار v2.0)."""
    user_id = update.effective_user.id
    phone_price = get_phone_price()
    balance = await get_user_balance(user_id)

    if balance < phone_price:
        await update.message.reply_text(get_messages()['low_balance'])
        return

    try:
        url = "https://api.durianrcs.com/out/ext_api/getMobile"
        params = {
            'name': USERNAME,
            'ApiKey': API_KEY,
            'cuy': country_code,     # مثال: 'us' أو 'bo'
            'pid': service_pid,      # رقم المشروع (الخدمة)
            'num': NUM_COUNT,        # عدد الأرقام المطلوبة (عادة 1)
            'noblack': 0,            # فلترة البلاك ليست الخاصة بالمستخدم فقط
            'serial': SERIAL,        # 2 = single
            'secret_key': 'null',
            'vip': 'null'
        }

        logger.info(f"🔹 API Request to getMobile: {params}")
        response = requests.get(url, params=params, timeout=15)
        response.raise_for_status()

        data = response.json()
        logger.info(f"🔹 API Response: {data}")

        if data.get("code") == 200:
            phone = data.get("data")
            if not phone:
                raise ValueError("لم يتم استلام رقم من السيرفر")

            # خصم السعر من الرصيد
            new_balance = balance - phone_price
            await update_user_balance(user_id, new_balance)
            context.user_data['temp_phone'] = phone
            context.user_data['temp_pid'] = service_pid  # لتستخدم لاحقاً في get_sms_code

            await update.message.reply_text(get_messages()['phone_received'].format(phone))
            await update.message.reply_text(get_messages()['deducted'].format(phone_price, new_balance))
        else:
            code = data.get("code")
            msg = data.get("msg", "Unknown error")
            raise ValueError(f"API Error {code}: {msg}")

    except Exception as e:
        logger.error(f"❌ Error buying phone: {e}")
        await update.message.reply_text(get_messages()['error'].format(f"شراء الرقم: {str(e)}"))

async def get_sms_code(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """جلب كود التحقق من DurianRCS API."""
    user_id = update.effective_user.id
    phone = context.user_data.get('temp_phone')
    service_pid = context.user_data.get('temp_pid')

    if not phone:
        await update.message.reply_text(get_messages()['no_phone'])
        return

    await update.message.reply_text(get_messages()['searching'])

    try:
        url = "https://api.durianrcs.com/out/ext_api/getMsg"
        params = {
            'name': USERNAME,
            'ApiKey': API_KEY,
            'pid': service_pid,
            'pn': phone,
            'serial': SERIAL
        }

        logger.info(f"🔹 API Request to getMsg: {params}")

        start_time = time.time()
        while time.time() - start_time < 60:  # انتظر حتى 60 ثانية
            response = requests.get(url, params=params, timeout=15)
            response.raise_for_status()

            data = response.json()
            logger.info(f"🔹 SMS Response: {data}")

            if data.get("code") == 200:
                sms_code = data.get("data")
                await update.message.reply_text(f"✅ الكود المستلم: `{sms_code}`", parse_mode='Markdown')
                context.user_data.pop('temp_phone', None)
                context.user_data.pop('temp_pid', None)
                return
            elif data.get("code") in [908, 203]:
                # لم يصل كود بعد، انتظر وحاول مجدداً
                time.sleep(5)
                continue
            else:
                code = data.get("code")
                msg = data.get("msg", "Unknown error")
                raise ValueError(f"API Error {code}: {msg}")

        # إذا انتهى الوقت ولم يأتِ الكود
        await update.message.reply_text(get_messages()['no_sms'])
    except Exception as e:
        logger.error(f"❌ Error getting SMS: {e}")
        await update.message.reply_text(get_messages()['error'].format(str(e)))

# 6. Handlers للتسجيل والأوامر

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle /start: Register or show main menu."""
    user_id = update.effective_user.id
    if user_id == ADMIN_ID:
        await admin_panel(update, context)
        return ConversationHandler.END
    
    if is_registered(user_id):
        await show_main_menu(update, context)
        return ConversationHandler.END
    else:
        await update.message.reply_text(get_messages()['welcome'])
        await update.message.reply_text(get_messages()['ask_username'])
        return USERNAME_STATE

async def username_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle username input during registration."""
    username = update.message.text.strip()
    try:
        # Check if username exists
        data = supabase.table('users').select('username').eq('username', username).execute()
        if data.data:
            await update.message.reply_text(get_messages()['username_taken'])
            return USERNAME_STATE
        
        context.user_data['reg_username'] = username
        await update.message.reply_text(get_messages()['username_saved'])
        await update.message.reply_text('أرسل كلمة المرور:')
        return PASSWORD_STATE
    except Exception as e:
        logger.error(f"DB username check error: {e}")
        await update.message.reply_text(get_messages()['error'].format("التحقق من اسم المستخدم."))
        return USERNAME_STATE

async def password_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle password input during registration."""
    password = update.message.text.strip()
    hashed_pw = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    context.user_data['reg_password'] = hashed_pw
    await update.message.reply_text(get_messages()['password_saved'])
    context.user_data['captcha_attempts'] = 0
    return CAPTCHA_STATE

async def captcha_check(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Handle captcha during registration."""
    answer = update.message.text.strip()
    if answer == "1":
        user = update.effective_user
        try:
            supabase.table('users').insert({
                'user_id': user.id,
                'username': context.user_data['reg_username'],
                'password_hash': context.user_data['reg_password'],
                'balance': 0.0
            }).execute()
            await update.message.reply_text(get_messages()['captcha_success'], reply_markup=get_main_keyboard())
            context.user_data.clear()
            return ConversationHandler.END
        except Exception as e:
            logger.error(f"DB user insert error: {e}")
            await update.message.reply_text(get_messages()['error'].format("التسجيل."))
            return CAPTCHA_STATE
    else:
        context.user_data['captcha_attempts'] = context.user_data.get('captcha_attempts', 0) + 1
        if context.user_data['captcha_attempts'] >= 3:
            await update.message.reply_text(get_messages()['too_many_attempts'], reply_markup=get_main_keyboard())
            context.user_data.clear()
            return ConversationHandler.END
        await update.message.reply_text(get_messages()['wrong_captcha'])
        return CAPTCHA_STATE

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Cancel ongoing conversation."""
    await update.message.reply_text("تم إلغاء العملية.", reply_markup=get_main_keyboard())
    context.user_data.clear()
    return ConversationHandler.END

async def show_main_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show main menu."""
    await update.message.reply_text(get_messages()['choose_action'], reply_markup=get_main_keyboard())
    # Clear recharge data
    context.user_data.pop('recharge_step', None)
    context.user_data.pop('recharge_type', None)
    context.user_data.pop('temp_transfer', None)
    context.user_data.pop('temp_photo', None)
    context.user_data.pop('waiting_country', None)
    context.user_data.pop('selected_country', None)
    context.user_data.pop('waiting_service', None)
    context.user_data.pop('selected_service', None)
    context.user_data.pop('service_page', None)

async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show advanced admin panel."""
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        await update.message.reply_text(get_messages()['access_denied'])
        return
    
    # Clear editing data
    context.user_data.pop('editing', None)
    context.user_data.pop('edit_key', None)
    context.user_data.pop('edit_method', None)
    context.user_data.pop('address_select', None)
    
    await update.message.reply_text(get_messages()['admin_welcome'], reply_markup=get_admin_keyboard(), parse_mode='Markdown')

# 7. دوال إجراءات المستخدمين والأدمن

async def show_user_balance(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show user balance."""
    user_id = update.effective_user.id
    balance = await get_user_balance(user_id)
    await update.message.reply_text(get_messages()['balance'].format(balance))

async def start_recharge_flow(update: Update, context: ContextTypes.DEFAULT_TYPE, method: str, is_syriatel: bool = False):
    """Start the recharge flow for a method."""
    context.user_data['recharge_type'] = method
    if is_syriatel:
        context.user_data['recharge_step'] = WAITING_TRANSFER_ID
        await update.message.reply_text(get_messages()['syriatel_cash_prompt'], parse_mode='Markdown')
    else:
        context.user_data['recharge_step'] = WAITING_PHOTO
        address = get_recharge_address(method)
        msg = get_recharge_message(method, address)
        await update.message.reply_text(msg, parse_mode='Markdown')

async def show_admin_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show advanced admin statistics."""
    try:
        users_data = supabase.table('users').select('*').execute()
        user_count = len(users_data.data)
        
        # Get today's recharge requests (simple count)
        today_requests = supabase.table('recharge_requests').select('*').gte('created_at', str(time.time() - 86400)).execute()
        requests_count = len(today_requests.data)
        
        stats_text = get_messages()['admin_stats'].format(user_count, requests_count)
        await update.message.reply_text(stats_text, parse_mode='Markdown')
    except Exception as e:
        logger.error(f"Error fetching stats: {e}")
        await update.message.reply_text(get_messages()['error'].format("جلب الإحصائيات."))

async def start_address_edit(update: Update, context: ContextTypes.DEFAULT_TYPE, method: str):
    """Start editing address for method."""
    key_map = {
        "شام كاش (ل.س)": 'sham_cash_sp',
        "شام كاش (دولار)": 'sham_cash_usd',
        "USDT (BEP20)": 'usdt_bep20',
        "سيرياتيل كاش": 'syriatel_cash'
    }
    edit_key = key_map.get(method)
    if edit_key:
        context.user_data['editing'] = 'address'
        context.user_data['edit_key'] = edit_key
        context.user_data['edit_method'] = method
        await update.message.reply_text(f"أرسل **العنوان الجديد** لـ **{method}**:", parse_mode='Markdown')
    else:
        await update.message.reply_text("خطأ في اختيار الطريقة.")

async def manage_requests(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Show pending requests."""
    try:
        pending_requests = supabase.table('recharge_requests').select('*').eq('status', 'pending').execute()
        if not pending_requests.data:
            await update.message.reply_text("لا توجد طلبات قيد الانتظار.")
            return
        
        text = get_messages()['requests_list']
        for req in pending_requests.data[:10]:  # Limit to 10
            text += f"\n• ID: {req['id']} | المستخدم: {req['username']} | المبلغ: {req['amount']}"
        
        await update.message.reply_text(text, parse_mode='Markdown')
    except Exception as e:
        logger.error(f"Error fetching requests: {e}")
        await update.message.reply_text(get_messages()['error'].format("جلب الطلبات."))

async def manage_services(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manage services."""
    await update.message.reply_text(get_messages()['services_manage'], reply_markup=get_services_keyboard(), parse_mode='Markdown')

async def manage_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Manage users."""
    await update.message.reply_text("🔒 **إدارة المستخدمين**:\n\nاختر إجراءً:", reply_markup=get_users_management_keyboard(), parse_mode='Markdown')

# 8. Handlers للصور والإدخالات

async def handle_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle photo proof for recharge."""
    current_step = context.user_data.get('recharge_step')
    if current_step != WAITING_PHOTO:
        return  # Ignore if not in photo waiting state

    photo_file_id = update.message.photo[-1].file_id
    context.user_data['temp_photo'] = photo_file_id
    context.user_data['recharge_step'] = WAITING_AMOUNT
    await update.message.reply_text(get_messages()['photo_sent'])
    await update.message.reply_text(get_messages()['ask_amount'], parse_mode='Markdown')

async def admin_approval_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle admin approve/reject callbacks."""
    query = update.callback_query
    await query.answer()
    
    if query.from_user.id != ADMIN_ID:
        await query.edit_message_text("❌ ليس لديك صلاحية.")
        return

    parts = query.data.split('_')
    if len(parts) != 3:
        await query.answer("بيانات غير صالحة.")
        return
    action = parts[1]
    try:
        request_id = int(parts[2])
    except ValueError:
        await query.answer("ID غير صالح.")
        return
    
    try:
        request_data = supabase.table('recharge_requests').select('*').eq('id', request_id).execute().data
        if not request_data or request_data[0]['status'] != 'pending':
            await query.edit_message_text("⚠️ تمت معالجة هذا الطلب مسبقاً.")
            return
        
        req = request_data[0]
        user_id = req['user_id']
        amount = req['amount']
        
        if action == 'approve':
            current_balance = await get_user_balance(user_id)
            new_balance = current_balance + amount
            await update_user_balance(user_id, new_balance)
            supabase.table('recharge_requests').update({'status': 'approved'}).eq('id', request_id).execute()
            await context.bot.send_message(user_id, get_messages()['approval_notification'].format(amount, new_balance))
            if query.message.photo:
                await query.edit_message_caption(caption=query.message.caption + "\n\n✅ تمت الموافقة.", parse_mode='Markdown')
            else:
                await query.edit_message_text(text=query.message.text + "\n\n✅ تمت الموافقة.", parse_mode='Markdown')
            
        elif action == 'reject':
            supabase.table('recharge_requests').update({'status': 'rejected'}).eq('id', request_id).execute()
            await context.bot.send_message(user_id, get_messages()['rejection_notification'])
            if query.message.photo:
                await query.edit_message_caption(caption=query.message.caption + "\n\n❌ تم الرفض.", parse_mode='Markdown')
            else:
                await query.edit_message_text(text=query.message.text + "\n\n❌ تم الرفض.", parse_mode='Markdown')
            
    except Exception as e:
        logger.error(f"Error in approval: {e}")
        await query.edit_message_text(f"خطأ: {str(e)}")

# 9. دالة رئيسية لمعالجة الأزرار والنصوص

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Unified handler for buttons and text inputs."""
    text = update.message.text.strip()
    user_id = update.effective_user.id
    messages = get_messages()
    
    logger.info(f"Button handler: user {user_id}, text: '{text}', waiting_country: {context.user_data.get('waiting_country')}, waiting_service: {context.user_data.get('waiting_service')}")
    
    # Handle country selection
    if context.user_data.get('waiting_country', False):
        if text == "🇺🇸 USA":
            context.user_data['selected_country'] = 'us'
            country_name = "USA"
            logger.info(f"✅ Selected country: {context.user_data['selected_country']}")
            
            # تحضير قائمة الخدمات
            context.user_data.pop('waiting_country')
            page_info = ""
            markup, page_info = get_services_keyboard(context)
            await update.message.reply_text(
                get_messages()['country_selected'].format(country_name)
                + ("\n" + page_info if page_info else ""),
                reply_markup=markup,
                parse_mode='Markdown'
            )
            context.user_data['waiting_service'] = True
            return

        elif text == "رجوع":
            context.user_data.pop('waiting_country')
            await show_main_menu(update, context)
            return

        else:
            await update.message.reply_text(messages['use_buttons'])
            return
    
    # Handle service selection
    if context.user_data.get('waiting_service', False):
        service_pid = SERVICE_TO_PID.get(text)
        if service_pid:
            context.user_data['selected_service'] = text
            context.user_data.pop('waiting_service')
            service_name = text
            await update.message.reply_text(get_messages()['service_selected'].format(service_name), parse_mode='Markdown')
            # Now buy the phone with selected country and service
            country_code = context.user_data.get('selected_country', 'us')  # Default to USA if not set
            await buy_temp_phone(update, context, country_code, service_pid)
            # Clear selection data
            context.user_data.pop('selected_country', None)
            context.user_data.pop('selected_service', None)
            context.user_data.pop('service_page', None)
            return
        elif text in [get_messages()['next_page'], get_messages()['prev_page']]:
            # Handle pagination
            services = list(SERVICE_TO_PID.keys())
            page = context.user_data.get('service_page', 0)
            items_per_page = 6
            if text == get_messages()['next_page'] and (page + 1) * items_per_page < len(services):
                context.user_data['service_page'] = page + 1
            elif text == get_messages()['prev_page'] and page > 0:
                context.user_data['service_page'] = page - 1
            
            markup, page_info = get_services_keyboard(context)
            await update.message.reply_text(get_messages()['choose_service'] + ("\n" + page_info if page_info else ""), reply_markup=markup, parse_mode='Markdown')
            return
        elif text == "رجوع":
            context.user_data.pop('waiting_service')
            context.user_data.pop('selected_country', None)
            context.user_data.pop('service_page', None)
            await show_main_menu(update, context)
            return
        else:
            await update.message.reply_text(messages['use_buttons'])
            return
    
    # Priority: Handle state-based text inputs first
    if user_id == ADMIN_ID:
        editing = context.user_data.get('editing')
        if editing == 'price':
            try:
                new_price = float(text)
                supabase.table('settings').update({'value': str(new_price)}).eq('key', 'phone_price').execute()
                await update.message.reply_text(messages['price_updated'].format(new_price))
                context.user_data.pop('editing')
                await admin_panel(update, context)
            except ValueError:
                await update.message.reply_text("❌ قيمة غير صالحة. أرسل رقماً.")
            return
        elif editing == 'address':
            key = context.user_data.pop('edit_key')
            method = context.user_data.pop('edit_method')
            try:
                supabase.table('settings').update({'value': text}).eq('key', key).execute()
                await update.message.reply_text(messages['address_updated'].format(method, text))
            except Exception as e:
                logger.error(f"DB address update error: {e}")
                await update.message.reply_text(messages['error'].format("تحديث العنوان."))
            context.user_data.pop('editing')
            await admin_panel(update, context)
            return
    else:
        step = context.user_data.get('recharge_step')
        if step == WAITING_TRANSFER_ID:
            context.user_data['temp_transfer'] = text
            context.user_data['recharge_step'] = WAITING_PHOTO
            await update.message.reply_text(messages['transfer_id_saved'])
            await update.message.reply_text("أرسل **صورة إثبات التحويل** الآن.", parse_mode='Markdown')
            return
        elif step == WAITING_AMOUNT:
            try:
                amount = float(text)
                await send_recharge_request_to_admin(
                    update, context, amount, context.user_data['recharge_type'],
                    transfer_id=context.user_data.pop('temp_transfer', None),
                    photo_file_id=context.user_data.pop('temp_photo', None)
                )
                context.user_data.pop('recharge_step', None)
                context.user_data.pop('recharge_type', None)
            except ValueError:
                await update.message.reply_text("❌ المبلغ غير صالح. أرسل رقماً صحيحاً أو عشرياً.")
            return

    # Handle buttons and actions
    if text == "رجوع":
        if user_id == ADMIN_ID:
            await admin_panel(update, context)
        else:
            await show_main_menu(update, context)
        return

    if user_id == ADMIN_ID:
        # Admin actions - Enhanced professional logic
        if text == "📊 الإحصائيات":
            await show_admin_stats(update, context)
        elif text == "⚙️ تعديل سعر الرقم":
            await update.message.reply_text(messages['edit_price'].format(get_phone_price()), parse_mode='Markdown')
            context.user_data['editing'] = 'price'
        elif text == "📝 تعديل عناوين الشحن":
            await update.message.reply_text(messages['edit_addresses_prompt'], reply_markup=get_charge_keyboard(), parse_mode='Markdown')
            context.user_data['address_select'] = True
        elif text == "📋 طلبات الشحن":
            await manage_requests(update, context)
        elif text == "🛠️ إدارة الخدمات":
            await manage_services(update, context)
        elif text == "🔒 إدارة المستخدمين":
            await manage_users(update, context)
        elif text == "📤 تصدير البيانات":
            await update.message.reply_text("📤 **تصدير البيانات**: قيد التطوير (سيتم إضافة CSV export قريباً).")
        elif text == "تفعيل/تعطيل الخدمة":
            await update.message.reply_text("قيد التطوير.")
        elif text == "تعديل الإعدادات":
            await update.message.reply_text("قيد التطوير.")
        elif text == "حظر مستخدم":
            await update.message.reply_text("أرسل ID المستخدم لحظره.")
            context.user_data['editing'] = 'ban_user'
        elif text == "إضافة رصيد يدوي":
            await update.message.reply_text("أرسل ID المستخدم والمبلغ (مثال: 123 50.0).")
            context.user_data['editing'] = 'add_balance'
        elif text == "عرض جميع المستخدمين":
            try:
                users = supabase.table('users').select('user_id, username, balance').execute()
                text = "👥 **جميع المستخدمين**:\n\n"
                for u in users.data[:20]:  # Limit to 20
                    text += f"• @{u['username']} (ID: {u['user_id']}) - رصيد: {u['balance']}\n"
                await update.message.reply_text(text, parse_mode='Markdown')
            except Exception as e:
                await update.message.reply_text(get_messages()['error'].format("عرض المستخدمين."))
        elif context.user_data.get('address_select', False) and text in ["شام كاش (ل.س)", "شام كاش (دولار)", "USDT (BEP20)", "سيرياتيل كاش"]:
            await start_address_edit(update, context, text)
            context.user_data.pop('address_select', None)
        elif context.user_data.get('editing') == 'ban_user':
            try:
                ban_id = int(text)
                supabase.table('users').update({'banned': True}).eq('user_id', ban_id).execute()
                await update.message.reply_text(f"✅ تم حظر المستخدم {ban_id}.")
            except ValueError:
                await update.message.reply_text("❌ ID غير صالح.")
            context.user_data.pop('editing')
            await admin_panel(update, context)
        elif context.user_data.get('editing') == 'add_balance':
            try:
                parts = text.split()
                user_id = int(parts[0])
                amount = float(parts[1])
                current = await get_user_balance(user_id)
                new = current + amount
                await update_user_balance(user_id, new)
                await update.message.reply_text(f"✅ تم إضافة {amount} رصيد للمستخدم {user_id}. الجديد: {new}.")
            except (ValueError, IndexError):
                await update.message.reply_text("❌ تنسيق خاطئ. استخدم: ID المبلغ")
            context.user_data.pop('editing')
            await admin_panel(update, context)
        else:
            await update.message.reply_text(messages['use_buttons'])
    else:
        # User actions
        if text == "🔑 شراء رقم مؤقت":
            await update.message.reply_text(get_messages()['choose_country'], reply_markup=get_countries_keyboard(), parse_mode='Markdown')
            context.user_data['waiting_country'] = True
            return
        elif text == "💰 رصيدي":
            await show_user_balance(update, context)
        elif text == "💳 شحن الحساب":
            await update.message.reply_text(messages['choose_method'], reply_markup=get_charge_keyboard(), parse_mode='Markdown')
        elif text == "✉️ الحصول على الكود":
            await get_sms_code(update, context)
        elif text in ["شام كاش (ل.س)", "شام كاش (دولار)", "USDT (BEP20)"]:
            await start_recharge_flow(update, context, text)
        elif text == "سيرياتيل كاش":
            await start_recharge_flow(update, context, text, is_syriatel=True)
        else:
            await update.message.reply_text(messages['use_buttons'])

# 10. معالج الأخطاء

async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Log errors caused by Updates."""
    logger.warning('Update "%s" caused error "%s"', update, context.error)

# 11. الدالة الرئيسية

def main():
    """Start the bot with webhook."""
    if not BOT_TOKEN or not os.getenv('RENDER_EXTERNAL_HOSTNAME'):
        logger.error("Missing BOT_TOKEN or RENDER_EXTERNAL_HOSTNAME.")
        return

    app = Application.builder().token(BOT_TOKEN).build()

    # Registration Conversation
    reg_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],
        states={
            USERNAME_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, username_handler)],
            PASSWORD_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, password_handler)],
            CAPTCHA_STATE: [MessageHandler(filters.TEXT & ~filters.COMMAND, captcha_check)],
        },
        fallbacks=[CommandHandler('cancel', cancel)],
    )
    app.add_handler(reg_handler)
    app.add_handler(CommandHandler("admin", admin_panel))

    # Other handlers
    app.add_handler(CallbackQueryHandler(admin_approval_callback, pattern="^req_(approve|reject)_"))
    app.add_handler(MessageHandler(filters.PHOTO, handle_photo))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, button_handler))

    # Error Handler
    app.add_error_handler(error_handler)

    # Webhook
    PORT = int(os.getenv('PORT', 10000))
    HOSTNAME = os.getenv('RENDER_EXTERNAL_HOSTNAME')
    WEBHOOK_URL = f"https://{HOSTNAME}/{BOT_TOKEN}"
    app.bot.set_webhook(url=WEBHOOK_URL)
    logger.info(f"Webhook set: {WEBHOOK_URL}")

    app.run_webhook(
        listen="0.0.0.0",
        port=PORT,
        url_path=BOT_TOKEN,
        webhook_url=WEBHOOK_URL
    )

if __name__ == "__main__":
    main()
